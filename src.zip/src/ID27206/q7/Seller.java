package ID27206.q7;

public class Seller extends Property{
    private String sellerName;
    private String contactNumber;

    public Seller(int id, String agencyName, String location, String phoneNumber,
                  String agentName, String email, String licenseNumber,
                  String propertyCode, String propertyType, double price,
                  String sellerName, String contactNumber) throws DataException {
        super(id, agencyName, location, phoneNumber, agentName, email, licenseNumber,
                propertyCode, propertyType, price);
        if (sellerName == null || sellerName.trim().isEmpty()) {
            throw new DataException("Seller name cannot be empty");
        }
        if (contactNumber == null || contactNumber.trim().isEmpty()) {
            throw new DataException("Contact number cannot be empty");
        }
        this.sellerName = sellerName;
        this.contactNumber = contactNumber;
    }

    public String getSellerName() { return sellerName; }
    public void setSellerName(String sellerName) throws DataException {
        if (sellerName == null || sellerName.trim().isEmpty()) {
            throw new DataException("Seller name cannot be empty");
        }
        this.sellerName = sellerName;
    }
    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) throws DataException {
        if (contactNumber == null || contactNumber.trim().isEmpty()) {
            throw new DataException("Contact number cannot be empty");
        }
        this.contactNumber = contactNumber;
    }
}
