package ID27206.q7;

import java.time.LocalDate;

public class Payment extends Agreement{
    private double paymentAmount;
    private LocalDate paymentDate;

    public Payment(int id, String agencyName, String location, String phoneNumber,
                   String agentName, String email, String licenseNumber,
                   String propertyCode, String propertyType, double price,
                   String sellerName, String contactNumber,
                   String buyerName, String buyerEmail,
                   LocalDate agreementDate, String terms,
                   double paymentAmount, LocalDate paymentDate) throws DataException {
        super(id, agencyName, location, phoneNumber, agentName, email, licenseNumber,
                propertyCode, propertyType, price, sellerName, contactNumber,
                buyerName, buyerEmail, agreementDate, terms);
        if (paymentAmount <= 0) {
            throw new DataException("Payment amount must be greater than 0");
        }
        this.paymentAmount = paymentAmount;
        this.paymentDate = paymentDate;
    }

    public double getPaymentAmount() { return paymentAmount; }
    public void setPaymentAmount(double paymentAmount) throws DataException {
        if (paymentAmount <= 0) {
            throw new DataException("Payment amount must be greater than 0");
        }
        this.paymentAmount = paymentAmount;
    }
    public LocalDate getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDate paymentDate) { this.paymentDate = paymentDate; }
}
