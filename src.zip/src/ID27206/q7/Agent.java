package ID27206.q7;

public class Agent extends Agency{
    private String agentName;
    private String email;
    private String licenseNumber;

    public Agent(int id, String agencyName, String location, String phoneNumber,
                 String agentName, String email, String licenseNumber) throws DataException {
        super(id, agencyName, location, phoneNumber);
        if (!isValidEmail(email)) {
            throw new DataException("Invalid email format");
        }
        this.agentName = agentName;
        this.email = email;
        this.licenseNumber = licenseNumber;
    }

    private boolean isValidEmail(String email) {
        return email != null && email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    }

    public String getAgentName() { return agentName; }
    public void setAgentName(String agentName) { this.agentName = agentName; }
    public String getEmail() { return email; }
    public void setEmail(String email) throws DataException {
        if (!isValidEmail(email)) {
            throw new DataException("Invalid email format");
        }
        this.email = email;
    }
    public String getLicenseNumber() { return licenseNumber; }
    public void setLicenseNumber(String licenseNumber) { this.licenseNumber = licenseNumber; }
}
