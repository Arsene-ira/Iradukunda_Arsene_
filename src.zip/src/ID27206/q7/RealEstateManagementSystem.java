package ID27206.q7;
import java.time.LocalDate;
import java.util.*;

public class RealEstateManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("27206 - REAL ESTATE MANAGEMENT SYSTEM");
            System.out.println("=".repeat(50));

            // Entity & Agency Information
            System.out.print("Enter Record ID: ");
            int id = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Enter Agency Name: ");
            String agencyName = scanner.nextLine();

            System.out.print("Enter Agency Location: ");
            String location = scanner.nextLine();

            System.out.print("Enter Agency Phone Number: ");
            String phoneNumber = scanner.nextLine();

            // Agent Information
            System.out.print("Enter Agent Name: ");
            String agentName = scanner.nextLine();

            System.out.print("Enter Agent Email: ");
            String email = scanner.nextLine();

            System.out.print("Enter Agent License Number: ");
            String licenseNumber = scanner.nextLine();

            // Property Information
            System.out.print("Enter Property Code: ");
            String propertyCode = scanner.nextLine();

            System.out.print("Enter Property Type (House/Apartment/Land): ");
            String propertyType = scanner.nextLine();

            System.out.print("Enter Property Price: ");
            double price = scanner.nextDouble();
            scanner.nextLine();

            // Seller Information
            System.out.print("Enter Seller Name: ");
            String sellerName = scanner.nextLine();

            System.out.print("Enter Seller Contact Number: ");
            String contactNumber = scanner.nextLine();

            // Buyer Information
            System.out.print("Enter Buyer Name: ");
            String buyerName = scanner.nextLine();

            System.out.print("Enter Buyer Email: ");
            String buyerEmail = scanner.nextLine();

            // Agreement Information
            System.out.print("Enter Agreement Date (YYYY-MM-DD): ");
            String agreementDateStr = scanner.nextLine();
            LocalDate agreementDate = LocalDate.parse(agreementDateStr);

            System.out.print("Enter Agreement Terms: ");
            String terms = scanner.nextLine();

            // Payment Information
            System.out.print("Enter Payment Amount: ");
            double paymentAmount = scanner.nextDouble();
            scanner.nextLine();

            System.out.print("Enter Payment Date (YYYY-MM-DD): ");
            String paymentDateStr = scanner.nextLine();
            LocalDate paymentDate = LocalDate.parse(paymentDateStr);

            // Commission Information
            System.out.print("Enter Commission Rate (%): ");
            double commissionRate = scanner.nextDouble();

            // Create RealEstateRecord
            RealEstateRecord record = new RealEstateRecord(
                    id, agencyName, location, phoneNumber,
                    agentName, email, licenseNumber,
                    propertyCode, propertyType, price,
                    sellerName, contactNumber,
                    buyerName, buyerEmail,
                    agreementDate, terms,
                    paymentAmount, paymentDate,
                    commissionRate
            );

            // Display Invoice
            record.displayInvoice();

        } catch (DataException e) {
            System.out.println("\n27206 - ERROR: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("\n27206 - ERROR: Invalid input format - " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
