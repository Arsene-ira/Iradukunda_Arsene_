package ID27206.q8;

import java.time.LocalDate;

public class Entity {
    private int id;
    private LocalDate createdDate;
    private LocalDate updatedDate;

    public Entity(int id) throws DataException {
        if (id <= 0) {
            throw new DataException("ID must be greater than 0");
        }
        this.id = id;
        this.createdDate = LocalDate.now();
        this.updatedDate = LocalDate.now();
    }

    public int getId() { return id; }
    public void setId(int id) throws DataException {
        if (id <= 0) {
            throw new DataException("ID must be greater than 0");
        }
        this.id = id;
        this.updatedDate = LocalDate.now();
    }

    public LocalDate getCreatedDate() { return createdDate; }
    public LocalDate getUpdatedDate() { return updatedDate; }
    public void setUpdatedDate(LocalDate updatedDate) { this.updatedDate = updatedDate; }
}
