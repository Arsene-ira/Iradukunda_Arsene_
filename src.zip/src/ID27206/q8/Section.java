package ID27206.q8;

public class Section extends Library{
    private String sectionName;
    private String sectionCode;

    public Section(int id, String libraryName, String location, String phoneNumber,
                   String sectionName, String sectionCode) throws DataException {
        super(id, libraryName, location, phoneNumber);
        if (sectionName == null || sectionName.length() < 3) {
            throw new DataException("Section name must be at least 3 characters");
        }
        if (sectionCode == null || sectionCode.length() < 3) {
            throw new DataException("Section code must be at least 3 characters");
        }
        this.sectionName = sectionName;
        this.sectionCode = sectionCode;
    }

    public String getSectionName() { return sectionName; }
    public void setSectionName(String sectionName) { this.sectionName = sectionName; }

    public String getSectionCode() { return sectionCode; }
    public void setSectionCode(String sectionCode) throws DataException {
        if (sectionCode == null || sectionCode.length() < 3) {
            throw new DataException("Section code must be at least 3 characters");
        }
        this.sectionCode = sectionCode;
    }
}
