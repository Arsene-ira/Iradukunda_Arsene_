package ID27206.q8;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class LibraryManagementSystem {
    private static final String STUDENT_ID = "27206";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("=== Library Management System ===");
            System.out.println("Student ID: " + STUDENT_ID);
            System.out.println();

            // Entity ID
            System.out.print("Enter Entity ID: ");
            int id = scanner.nextInt();
            scanner.nextLine();

            // Library Information
            System.out.println("\n--- Library Information ---");
            System.out.print("Enter Library Name: ");
            String libName = scanner.nextLine();
            System.out.print("Enter Location: ");
            String location = scanner.nextLine();
            System.out.print("Enter Phone Number (10-15 digits): ");
            String phone = scanner.nextLine();

            // Section Information
            System.out.println("\n--- Section Information ---");
            System.out.print("Enter Section Name (min 3 chars): ");
            String secName = scanner.nextLine();
            System.out.print("Enter Section Code (min 3 chars): ");
            String secCode = scanner.nextLine();

            // Book Information
            System.out.println("\n--- Book Information ---");
            System.out.print("Enter Book Title: ");
            String title = scanner.nextLine();
            System.out.print("Enter Author: ");
            String author = scanner.nextLine();
            System.out.print("Enter ISBN (min 10 chars): ");
            String isbn = scanner.nextLine();

            // Member Information
            System.out.println("\n--- Member Information ---");
            System.out.print("Enter Member Name: ");
            String memName = scanner.nextLine();
            System.out.print("Enter Member ID: ");
            int memId = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Enter Contact Number: ");
            String contact = scanner.nextLine();

            // Borrow Information
            System.out.println("\n--- Borrow Information ---");
            System.out.print("Enter Borrow Date (YYYY-MM-DD): ");
            String borrowDateStr = scanner.nextLine();
            LocalDate borrowDate = LocalDate.parse(borrowDateStr);
            System.out.print("Enter Expected Return Date (YYYY-MM-DD): ");
            String returnDateStr = scanner.nextLine();
            LocalDate returnDate = LocalDate.parse(returnDateStr);

            // Fine Calculation
            System.out.println("\n--- Fine Information ---");
            System.out.print("Enter Fine Amount per Day: ");
            double fineAmount = scanner.nextDouble();
            System.out.print("Enter Actual Return Date (YYYY-MM-DD): ");
            scanner.nextLine();
            String actualReturnStr = scanner.nextLine();
            LocalDate actualReturn = LocalDate.parse(actualReturnStr);
            long daysLate = ChronoUnit.DAYS.between(returnDate, actualReturn);
            if (daysLate < 0) daysLate = 0;

            // Payment Information
            System.out.println("\n--- Payment Information ---");
            System.out.print("Enter Payment Date (YYYY-MM-DD): ");
            String payDateStr = scanner.nextLine();
            LocalDate payDate = LocalDate.parse(payDateStr);
            System.out.print("Enter Payment Mode (Cash/Card/Online): ");
            String payMode = scanner.nextLine();

            // Calculate Total Fine
            double totalFine = fineAmount * daysLate;
            if (totalFine <= 0) totalFine = 0.01; // Ensure > 0 for Record validation

            // Create LibraryRecord
            LibraryRecord record = new LibraryRecord(id, libName, location, phone,
                    secName, secCode, title, author, isbn,
                    memName, memId, contact,
                    borrowDate, returnDate,
                    fineAmount, daysLate,
                    payDate, payMode, totalFine);

            // Display Invoice
            displayInvoice(record);

        } catch (DataException e) {
            System.out.println("\n[" + STUDENT_ID + "] Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("\n[" + STUDENT_ID + "] Error: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }

    private static void displayInvoice(LibraryRecord record) {
        System.out.println("\n" + STUDENT_ID + " ========================================");
        System.out.println(STUDENT_ID + " LIBRARY FINE INVOICE");
        System.out.println(STUDENT_ID + " ========================================");
        System.out.println(STUDENT_ID + " Library: " + record.getLibraryName());
        System.out.println(STUDENT_ID + " Location: " + record.getLocation());
        System.out.println(STUDENT_ID + " Phone: " + record.getPhoneNumber());
        System.out.println(STUDENT_ID + " ----------------------------------------");
        System.out.println(STUDENT_ID + " Section: " + record.getSectionName() +
                " (" + record.getSectionCode() + ")");
        System.out.println(STUDENT_ID + " ----------------------------------------");
        System.out.println(STUDENT_ID + " Book: " + record.getTitle());
        System.out.println(STUDENT_ID + " Author: " + record.getAuthor());
        System.out.println(STUDENT_ID + " ISBN: " + record.getISBN());
        System.out.println(STUDENT_ID + " ----------------------------------------");
        System.out.println(STUDENT_ID + " Member: " + record.getMemberName());
        System.out.println(STUDENT_ID + " Member ID: " + record.getMemberId());
        System.out.println(STUDENT_ID + " Contact: " + record.getContactNumber());
        System.out.println(STUDENT_ID + " ----------------------------------------");
        System.out.println(STUDENT_ID + " Borrow Date: " + record.getBorrowDate());
        System.out.println(STUDENT_ID + " Expected Return: " + record.getReturnDate());
        System.out.println(STUDENT_ID + " Days Late: " + record.getDaysLate());
        System.out.println(STUDENT_ID + " Fine per Day: $" +
                String.format("%.2f", record.getFineAmount()));
        System.out.println(STUDENT_ID + " ----------------------------------------");
        System.out.println(STUDENT_ID + " TOTAL FINE: $" +
                String.format("%.2f", record.calculateFine()));
        System.out.println(STUDENT_ID + " ----------------------------------------");
        System.out.println(STUDENT_ID + " Payment Date: " + record.getPaymentDate());
        System.out.println(STUDENT_ID + " Payment Mode: " + record.getPaymentMode());
        System.out.println(STUDENT_ID + " Record ID: " + record.getId());
        System.out.println(STUDENT_ID + " ========================================");
    }
}
