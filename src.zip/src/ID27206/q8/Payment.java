package ID27206.q8;

import java.time.LocalDate;

public class Payment extends Fine{
    private LocalDate paymentDate;
    private String paymentMode;

    public Payment(int id, String libraryName, String location, String phoneNumber,
                   String sectionName, String sectionCode,
                   String title, String author, String ISBN,
                   String memberName, int memberId, String contactNumber,
                   LocalDate borrowDate, LocalDate returnDate,
                   double fineAmount, long daysLate,
                   LocalDate paymentDate, String paymentMode) throws DataException {
        super(id, libraryName, location, phoneNumber, sectionName, sectionCode,
                title, author, ISBN, memberName, memberId, contactNumber,
                borrowDate, returnDate, fineAmount, daysLate);
        if (paymentDate == null || paymentMode == null || paymentMode.isEmpty()) {
            throw new DataException("Payment date and payment mode cannot be empty");
        }
        this.paymentDate = paymentDate;
        this.paymentMode = paymentMode;
    }

    public LocalDate getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDate paymentDate) throws DataException {
        if (paymentDate == null) {
            throw new DataException("Payment date cannot be empty");
        }
        this.paymentDate = paymentDate;
    }

    public String getPaymentMode() { return paymentMode; }
    public void setPaymentMode(String paymentMode) throws DataException {
        if (paymentMode == null || paymentMode.isEmpty()) {
            throw new DataException("Payment mode cannot be empty");
        }
        this.paymentMode = paymentMode;
    }
}
