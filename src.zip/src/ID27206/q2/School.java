package ID27206.q2;


import java.util.regex.Pattern;

public class School extends Entity {
    private String schoolName;
    private String address;
    private String phoneNumber;
    private String email;

    public School(int id, String createdDate, String updatedDate, String schoolName,
                  String address, String phoneNumber, String email) throws SchoolDataException {
        super(id, createdDate, updatedDate);

        if (!isValidPhone(phoneNumber)) {
            throw new SchoolDataException("Phone number must be exactly 10 digits");
        }
        if (!isValidEmail(email)) {
            throw new SchoolDataException("Invalid email format");
        }

        this.schoolName = schoolName;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    private boolean isValidPhone(String phone) {
        return phone.length() == 10 && phone.matches("\\d+");
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        return Pattern.matches(emailRegex, email);
    }

    public String getSchoolName() { return schoolName; }
    public String getAddress() { return address; }
    public String getPhoneNumber() { return phoneNumber; }
    public String getEmail() { return email; }
}
