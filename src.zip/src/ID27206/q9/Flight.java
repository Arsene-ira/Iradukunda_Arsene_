package ID27206.q9;

public class Flight extends Airline{
    private String flightNumber;
    private String destination;
    private String departureTime;

    public Flight(int id, String airlineName, String address, String contactEmail,
                  String flightNumber, String destination, String departureTime) throws DataException {
        super(id, airlineName, address, contactEmail);
        if (flightNumber == null || flightNumber.trim().isEmpty()) {
            throw new DataException("Flight number cannot be empty");
        }
        if (destination == null || destination.trim().isEmpty()) {
            throw new DataException("Destination cannot be empty");
        }
        if (departureTime == null || departureTime.trim().isEmpty()) {
            throw new DataException("Departure time cannot be empty");
        }
        this.flightNumber = flightNumber;
        this.destination = destination;
        this.departureTime = departureTime;
    }

    public String getFlightNumber() { return flightNumber; }
    public void setFlightNumber(String flightNumber) throws DataException {
        if (flightNumber == null || flightNumber.trim().isEmpty()) {
            throw new DataException("Flight number cannot be empty");
        }
        this.flightNumber = flightNumber;
    }

    public String getDestination() { return destination; }
    public void setDestination(String destination) throws DataException {
        if (destination == null || destination.trim().isEmpty()) {
            throw new DataException("Destination cannot be empty");
        }
        this.destination = destination;
    }

    public String getDepartureTime() { return departureTime; }
    public void setDepartureTime(String departureTime) throws DataException {
        if (departureTime == null || departureTime.trim().isEmpty()) {
            throw new DataException("Departure time cannot be empty");
        }
        this.departureTime = departureTime;
    }
}
