package ID27206.q9;

public class Seat extends Passenger {
    private String seatNumber;
    private String seatType;

    public Seat(int id, String airlineName, String address, String contactEmail,
                String flightNumber, String destination, String departureTime,
                String passengerName, String passportNumber, String nationality,
                String seatNumber, String seatType) throws DataException {
        super(id, airlineName, address, contactEmail, flightNumber, destination,
                departureTime, passengerName, passportNumber, nationality);
        if (!seatType.equalsIgnoreCase("Economy") && !seatType.equalsIgnoreCase("Business")) {
            throw new DataException("Seat type must be 'Economy' or 'Business'");
        }
        this.seatNumber = seatNumber;
        this.seatType = seatType;
    }

    public String getSeatNumber() { return seatNumber; }
    public void setSeatNumber(String seatNumber) { this.seatNumber = seatNumber; }

    public String getSeatType() { return seatType; }
    public void setSeatType(String seatType) throws DataException {
        if (!seatType.equalsIgnoreCase("Economy") && !seatType.equalsIgnoreCase("Business")) {
            throw new DataException("Seat type must be 'Economy' or 'Business'");
        }
        this.seatType = seatType;
    }
}
