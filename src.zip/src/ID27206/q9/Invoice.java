package ID27206.q9;

import java.util.Date;

public class Invoice extends Payment{
    private double totalFare;

    public Invoice(int id, String airlineName, String address, String contactEmail,
                   String flightNumber, String destination, String departureTime,
                   String passengerName, String passportNumber, String nationality,
                   String seatNumber, String seatType, String ticketNumber, double price,
                   double baggageWeight, double baggageFee,
                   Date paymentDate, String paymentMode) throws DataException {
        super(id, airlineName, address, contactEmail, flightNumber, destination,
                departureTime, passengerName, passportNumber, nationality, seatNumber,
                seatType, ticketNumber, price, baggageWeight, baggageFee, paymentDate, paymentMode);
        this.totalFare = price + baggageFee;
        if (totalFare <= 0) {
            throw new DataException("Total fare must be greater than 0");
        }
    }

    public double getTotalFare() { return totalFare; }
    public void setTotalFare(double totalFare) throws DataException {
        if (totalFare <= 0) {
            throw new DataException("Total fare must be greater than 0");
        }
        this.totalFare = totalFare;
    }
}
