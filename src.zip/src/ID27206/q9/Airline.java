package ID27206.q9;

public class Airline extends Entity{
    private String airlineName;
    private String address;
    private String contactEmail;

    public Airline(int id, String airlineName, String address, String contactEmail) throws DataException {
        super(id);
        if (!isValidEmail(contactEmail)) {
            throw new DataException("Invalid email format");
        }
        this.airlineName = airlineName;
        this.address = address;
        this.contactEmail = contactEmail;
    }

    private boolean isValidEmail(String email) {
        return email != null && email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    }

    public String getAirlineName() { return airlineName; }
    public void setAirlineName(String airlineName) { this.airlineName = airlineName; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getContactEmail() { return contactEmail; }
    public void setContactEmail(String contactEmail) throws DataException {
        if (!isValidEmail(contactEmail)) {
            throw new DataException("Invalid email format");
        }
        this.contactEmail = contactEmail;
    }
}
