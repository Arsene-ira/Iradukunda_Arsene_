package ID27206.q9;

import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

public class AirlineTicketingSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("27206 - AIRLINE TICKETING SYSTEM");
            System.out.println("=".repeat(50));

            // Get ID
            System.out.print("\nEnter Record ID: ");
            int id = scanner.nextInt();
            scanner.nextLine();

            // Airline Information
            System.out.println("\n--- Enter Airline Information ---");
            System.out.print("Airline Name: ");
            String airlineName = scanner.nextLine();
            System.out.print("Address: ");
            String address = scanner.nextLine();
            System.out.print("Contact Email: ");
            String email = scanner.nextLine();

            // Flight Information
            System.out.println("\n--- Enter Flight Information ---");
            System.out.print("Flight Number: ");
            String flightNumber = scanner.nextLine();
            System.out.print("Destination: ");
            String destination = scanner.nextLine();
            System.out.print("Departure Time (e.g., 2025-11-22 10:30): ");
            String departureTime = scanner.nextLine();

            // Passenger Information
            System.out.println("\n--- Enter Passenger Information ---");
            System.out.print("Passenger Name: ");
            String passengerName = scanner.nextLine();
            System.out.print("Passport Number: ");
            String passportNumber = scanner.nextLine();
            System.out.print("Nationality: ");
            String nationality = scanner.nextLine();

            // Seat Information
            System.out.println("\n--- Enter Seat Information ---");
            System.out.print("Seat Number: ");
            String seatNumber = scanner.nextLine();
            System.out.print("Seat Type (Economy/Business): ");
            String seatType = scanner.nextLine();

            // Ticket Information
            System.out.println("\n--- Enter Ticket Information ---");
            System.out.print("Ticket Number: ");
            String ticketNumber = scanner.nextLine();
            System.out.print("Ticket Price: $");
            double price = scanner.nextDouble();

            // Baggage Information
            System.out.println("\n--- Enter Baggage Information ---");
            System.out.print("Baggage Weight (kg): ");
            double baggageWeight = scanner.nextDouble();
            System.out.print("Baggage Fee: $");
            double baggageFee = scanner.nextDouble();
            scanner.nextLine();

            // Payment Information
            System.out.println("\n--- Enter Payment Information ---");
            System.out.print("Payment Mode (Cash/Card/Online): ");
            String paymentMode = scanner.nextLine();

            // Create Ticket Record with all data
            TicketRecord record = new TicketRecord(id, airlineName, address, email,
                    flightNumber, destination, departureTime,
                    passengerName, passportNumber, nationality,
                    seatNumber, seatType, ticketNumber, price,
                    baggageWeight, baggageFee,
                    new Date(), paymentMode);

            // Display Invoice
            record.displayTicketRecord();

            System.out.println("\n27206 - Generated Invoice Total: $" +
                    String.format("%.2f", record.generateInvoice()));

        } catch (DataException e) {
            System.err.println("\nERROR: " + e.getMessage());
        } catch (InputMismatchException e) {
            System.err.println("\n27206 - ERROR: Invalid input type. Please enter the correct data type.");
        } catch (Exception e) {
            System.err.println("\n27206 - ERROR: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
