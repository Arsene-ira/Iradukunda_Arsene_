package ID27206.q6;


import java.util.Date;

public class Withdrawal extends Deposit{
    private double withdrawalAmount;
    private Date withdrawalDate;

    public Withdrawal(int id, String bankName, String branchCode, String address,
                      String accountNumber, String accountType, double balance,
                      String customerName, String email, String phoneNumber,
                      String transactionId, String transactionType, double amount) throws DataException {
        super(id, bankName, branchCode, address, accountNumber, accountType, balance,
                customerName, email, phoneNumber, transactionId, transactionType, amount);
        if (withdrawalAmount <= 0) {
            throw new DataException("Withdrawal amount must be greater than 0");
        }
        this.withdrawalAmount = withdrawalAmount;
        this.withdrawalDate = new Date();
    }



    public double getWithdrawalAmount() {
        return withdrawalAmount;
    }

    public void setWithdrawalAmount(double withdrawalAmount) throws DataException {
        if (withdrawalAmount <= 0) {
            throw new DataException("Withdrawal amount must be greater than 0");
        }
        this.withdrawalAmount = withdrawalAmount;
    }

    public Date getWithdrawalDate() {
        return withdrawalDate;
    }

    public void setWithdrawalDate(Date withdrawalDate) {
        this.withdrawalDate = withdrawalDate;
    }
}
