package ID27206.q6;

import java.util.Date;

public class Payment extends Loan{
    private double paymentAmount;
    private Date paymentDate;

    public Payment(int id, String bankName, String branchCode, String address,
                   String accountNumber, String accountType, double balance,
                   String customerName, String email, String phoneNumber,
                   String transactionId, String transactionType, double amount,
                   double paymentAmount) throws DataException {
        super(id, bankName, branchCode, address, accountNumber, accountType, balance,
                customerName, email, phoneNumber, transactionId, transactionType, amount);
        if (paymentAmount <= 0) {
            throw new DataException("Payment amount must be greater than 0");
        }
        this.paymentAmount = paymentAmount;
        this.paymentDate = new Date();
    }




    public double getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(double paymentAmount) throws DataException {
        if (paymentAmount <= 0) {
            throw new DataException("Payment amount must be greater than 0");
        }
        this.paymentAmount = paymentAmount;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }
}
