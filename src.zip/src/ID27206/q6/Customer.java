package ID27206.q6;

public class Customer extends Account{
    private String customerName;
    private String email;
    private String phoneNumber;

    public Customer(int id, String bankName, String branchCode, String address,
                    String accountNumber, String accountType, double balance,
                    String customerName, String email, String phoneNumber) throws DataException {
        super(id, bankName, branchCode, address, accountNumber, accountType, balance);
        if (!isValidEmail(email)) {
            throw new DataException("Invalid email format");
        }
        if (!isValidPhoneNumber(phoneNumber)) {
            throw new DataException("Invalid phone number format");
        }
        this.customerName = customerName;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }




    private boolean isValidEmail(String email) {
        return email != null && email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        return phoneNumber != null && phoneNumber.matches("^[0-9]{10,15}$");
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) throws DataException {
        if (!isValidEmail(email)) {
            throw new DataException("Invalid email format");
        }
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) throws DataException {
        if (!isValidPhoneNumber(phoneNumber)) {
            throw new DataException("Invalid phone number format");
        }
        this.phoneNumber = phoneNumber;
    }
}
