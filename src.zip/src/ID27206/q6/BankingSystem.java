package ID27206.q6;

import java.text.SimpleDateFormat;
import java.util.InputMismatchException;
import java.util.Scanner;

public class BankingSystem {
    private static final String STUDENT_ID = "27206";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("=== BANKING SYSTEM - STUDENT ID: " + STUDENT_ID + " ===\n");

            // Entity/Bank Data
            System.out.print("Enter Entity ID: ");
            int id = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Enter Bank Name: ");
            String bankName = scanner.nextLine();

            System.out.print("Enter Branch Code (min 3 chars): ");
            String branchCode = scanner.nextLine();

            System.out.print("Enter Address: ");
            String address = scanner.nextLine();

            // Account Data
            System.out.print("Enter Account Number: ");
            String accountNumber = scanner.nextLine();

            System.out.print("Enter Account Type: ");
            String accountType = scanner.nextLine();

            System.out.print("Enter Initial Balance: ");
            double balance = scanner.nextDouble();
            scanner.nextLine();

            // Customer Data
            System.out.print("Enter Customer Name: ");
            String customerName = scanner.nextLine();

            System.out.print("Enter Email: ");
            String email = scanner.nextLine();

            System.out.print("Enter Phone Number (10-15 digits): ");
            String phoneNumber = scanner.nextLine();

            // Transaction Data
            System.out.print("Enter Transaction ID: ");
            String transactionId = scanner.nextLine();

            System.out.print("Enter Transaction Type: ");
            String transactionType = scanner.nextLine();

            System.out.print("Enter Transaction Amount: ");
            double amount = scanner.nextDouble();

            // Loan Data
            System.out.print("Enter Loan Amount: ");
            double loanAmount = scanner.nextDouble();

            System.out.print("Enter Interest Rate (%): ");
            double interestRate = scanner.nextDouble();

            System.out.print("Enter Loan Duration (months): ");
            int duration = scanner.nextInt();

            // Create Loan Object
            Loan loan = new Loan(id, bankName, branchCode, address, accountNumber, accountType,
                    balance, customerName, email, phoneNumber, transactionId, transactionType,
                    amount, loanAmount, interestRate, duration);




            // Display Invoice
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

            System.out.println("\n" + "=".repeat(60));
            System.out.println("BANKING SYSTEM INVOICE - STUDENT ID: " + STUDENT_ID);
            System.out.println("=".repeat(60));

            System.out.println("\n--- BANK INFORMATION ---");
            System.out.println("Bank Name: " + loan.getBankName());
            System.out.println("Branch Code: " + loan.getBranchCode());
            System.out.println("Address: " + loan.getAddress());

            System.out.println("\n--- ACCOUNT INFORMATION ---");
            System.out.println("Account Number: " + loan.getAccountNumber());
            System.out.println("Account Type: " + loan.getAccountType());
            System.out.println("Current Balance: $" + String.format("%.2f", loan.getBalance()));

            System.out.println("\n--- CUSTOMER INFORMATION ---");
            System.out.println("Customer Name: " + loan.getCustomerName());
            System.out.println("Email: " + loan.getEmail());
            System.out.println("Phone Number: " + loan.getPhoneNumber());

            System.out.println("\n--- TRANSACTION INFORMATION ---");
            System.out.println("Transaction ID: " + loan.getTransactionId());
            System.out.println("Transaction Type: " + loan.getTransactionType());
            System.out.println("Transaction Amount: $" + String.format("%.2f", loan.getAmount()));

            System.out.println("\n--- LOAN DETAILS ---");
            System.out.println("Loan Amount: $" + String.format("%.2f", loan.getLoanAmount()));
            System.out.println("Interest Rate: " + String.format("%.2f", loan.getInterestRate()) + "%");
            System.out.println("Duration: " + loan.getDuration() + " months");

            System.out.println("\n--- SYSTEM INFORMATION ---");
            System.out.println("Entity ID: " + loan.getId());
            System.out.println("Created Date: " + sdf.format(loan.getCreatedDate()));
            System.out.println("Updated Date: " + sdf.format(loan.getUpdatedDate()));

            System.out.println("\n" + "=".repeat(60));
            System.out.println("END OF INVOICE - STUDENT ID: " + STUDENT_ID);
            System.out.println("=".repeat(60));

        } catch (DataException e) {
            System.out.println("\nERROR - " + STUDENT_ID + ": " + e.getMessage());
        } catch (InputMismatchException e) {
            System.out.println("\nERROR - " + STUDENT_ID + ": Invalid input format. Please enter correct data types.");
        } catch (Exception e) {
            System.out.println("\nERROR - " + STUDENT_ID + ": " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
