package ID27206.q6;

public class Account extends Bank{
    private String accountNumber;
    private String accountType;
    private double balance;

    public Account(int id, String bankName, String branchCode, String address,
                   String accountNumber, String accountType, double balance) throws DataException {
        super(id, bankName, branchCode, address);
        if (balance < 0) {
            throw new DataException("Balance must be greater than or equal to 0");
        }
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.balance = balance;
    }


    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) throws DataException {
        if (balance < 0) {
            throw new DataException("Balance must be greater than or equal to 0");
        }
        this.balance = balance;
    }
}
