package ID27206.q4;

import java.time.LocalDate;

public class Bill extends Payment{
    private double roomCharge;
    private double serviceCharge;
    private double totalBill;

    public Bill(int id, String hotelName, String address, String phoneNumber, String email,
                String roomNumber, String roomType, double pricePerNight,
                String customerName, String customerEmail, String contactNumber,
                LocalDate bookingDate, LocalDate checkInDate, LocalDate checkOutDate,
                String serviceName, double serviceCost,
                String paymentMethod, LocalDate paymentDate) throws DataException {
        super(id, hotelName, address, phoneNumber, email, roomNumber, roomType, pricePerNight,
                customerName, customerEmail, contactNumber, bookingDate, checkInDate, checkOutDate,
                serviceName, serviceCost, paymentMethod, paymentDate);

        this.roomCharge = pricePerNight * getNumberOfNights();
        this.serviceCharge = serviceCost;
        this.totalBill = generateBill();

        if (roomCharge <= 0 || serviceCharge < 0 || totalBill <= 0) {
            throw new DataException("All charges must be greater than 0");
        }
    }

    public double generateBill() {
        return roomCharge + serviceCharge;
    }

    public double getRoomCharge() { return roomCharge; }
    public double getServiceCharge() { return serviceCharge; }
    public double getTotalBill() { return totalBill; }
}
