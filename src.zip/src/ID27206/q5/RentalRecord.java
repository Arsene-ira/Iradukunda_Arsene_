package ID27206.q5;
import java.text.SimpleDateFormat;
import java.util.*;

final class RentalRecord extends Invoice{
    public RentalRecord(int id, String companyName, String address, String phoneNumber,
                        String branchName, String locationCode, String vehicleType,
                        String registrationNumber, double dailyRate, String customerName,
                        String licenseNumber, String contactNumber, Date rentalDate,
                        Date returnDate, int rentalDays, double rentalCharge,
                        double penaltyCharge, String paymentMode, String transactionId,
                        double totalCharge) throws DataException {
        super(id, companyName, address, phoneNumber, branchName, locationCode,
                vehicleType, registrationNumber, dailyRate, customerName,
                licenseNumber, contactNumber, rentalDate, returnDate, rentalDays,
                rentalCharge, penaltyCharge, paymentMode, transactionId, totalCharge);
    }

    public final double calculateTotalCharge() {
        return getRentalCharge() + getPenaltyCharge();
    }

    public void displayInvoice() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        System.out.println("\n" + "=".repeat(60));
        System.out.println("27206 - VEHICLE RENTAL INVOICE");
        System.out.println("=".repeat(60));
        System.out.println("Invoice ID: 27206-" + getId());
        System.out.println("\nCOMPANY DETAILS:");
        System.out.println("  Company Name: " + getCompanyName());
        System.out.println("  Address: " + getAddress());
        System.out.println("  Phone: " + getPhoneNumber());
        System.out.println("\nBRANCH DETAILS:");
        System.out.println("  Branch Name: " + getBranchName());
        System.out.println("  Location Code: " + getLocationCode());
        System.out.println("\nVEHICLE DETAILS:");
        System.out.println("  Vehicle Type: " + getVehicleType());
        System.out.println("  Registration Number: " + getRegistrationNumber());
        System.out.println("  Daily Rate: $" + String.format("%.2f", getDailyRate()));
        System.out.println("\nCUSTOMER DETAILS:");
        System.out.println("  Customer Name: " + getCustomerName());
        System.out.println("  License Number: " + getLicenseNumber());
        System.out.println("  Contact Number: " + getContactNumber());
        System.out.println("\nRENTAL DETAILS:");
        System.out.println("  Rental Date: " + sdf.format(getRentalDate()));
        System.out.println("  Return Date: " + sdf.format(getReturnDate()));
        System.out.println("  Rental Days: " + getRentalDays());
        System.out.println("\nCHARGE BREAKDOWN:");
        System.out.println("  Rental Charge: $" + String.format("%.2f", getRentalCharge()));
        System.out.println("  Penalty Charge: $" + String.format("%.2f", getPenaltyCharge()));
        System.out.println("  " + "-".repeat(40));
        System.out.println("  Total Charge: $" + String.format("%.2f", calculateTotalCharge()));
        System.out.println("\nPAYMENT DETAILS:");
        System.out.println("  Payment Mode: " + getPaymentMode());
        System.out.println("  Transaction ID: 27206-" + getTransactionId());
        System.out.println("=".repeat(60));
        System.out.println("Student ID: 27206");
        System.out.println("=".repeat(60));
    }
}
