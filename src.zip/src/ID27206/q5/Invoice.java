package ID27206.q5;
import java.util.*;

 class Invoice extends Payment{
    private double totalCharge;

    public Invoice(int id, String companyName, String address, String phoneNumber,
                   String branchName, String locationCode, String vehicleType,
                   String registrationNumber, double dailyRate, String customerName,
                   String licenseNumber, String contactNumber, Date rentalDate,
                   Date returnDate, int rentalDays, double rentalCharge,
                   double penaltyCharge, String paymentMode, String transactionId,
                   double totalCharge) throws DataException {
        super(id, companyName, address, phoneNumber, branchName, locationCode,
                vehicleType, registrationNumber, dailyRate, customerName,
                licenseNumber, contactNumber, rentalDate, returnDate, rentalDays,
                rentalCharge, penaltyCharge, paymentMode, transactionId);
        if (totalCharge <= 0) {
            throw new DataException("Total charge must be greater than 0");
        }
        this.totalCharge = totalCharge;
    }

    public double getTotalCharge() {
        return totalCharge;
    }

    public void setTotalCharge(double totalCharge) throws DataException {
        if (totalCharge <= 0) {
            throw new DataException("Total charge must be greater than 0");
        }
        this.totalCharge = totalCharge;
    }
}
