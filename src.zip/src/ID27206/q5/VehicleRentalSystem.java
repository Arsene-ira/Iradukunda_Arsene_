package ID27206.q5;
import java.util.*;

public class VehicleRentalSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("27206 - VEHICLE RENTAL SYSTEM");
            System.out.println("=".repeat(60));

            // Entity and Company Details
            System.out.print("\nEnter Record ID: ");
            int id = scanner.nextInt();
            scanner.nextLine(); // consume newline

            System.out.print("Enter Company Name: ");
            String companyName = scanner.nextLine();

            System.out.print("Enter Company Address: ");
            String address = scanner.nextLine();

            System.out.print("Enter Company Phone (10 digits): ");
            String phoneNumber = scanner.nextLine();

            // Branch Details
            System.out.print("Enter Branch Name: ");
            String branchName = scanner.nextLine();

            System.out.print("Enter Location Code (min 3 chars): ");
            String locationCode = scanner.nextLine();

            // Vehicle Details
            System.out.print("Enter Vehicle Type: ");
            String vehicleType = scanner.nextLine();

            System.out.print("Enter Registration Number: ");
            String registrationNumber = scanner.nextLine();

            System.out.print("Enter Daily Rate: $");
            double dailyRate = scanner.nextDouble();
            scanner.nextLine();

            // Customer Details
            System.out.print("Enter Customer Name: ");
            String customerName = scanner.nextLine();

            System.out.print("Enter License Number: ");
            String licenseNumber = scanner.nextLine();

            System.out.print("Enter Contact Number: ");
            String contactNumber = scanner.nextLine();

            // Rental Details
            System.out.print("Enter Rental Days: ");
            int rentalDays = scanner.nextInt();
            scanner.nextLine();

            Date rentalDate = new Date();
            Date returnDate = new Date(rentalDate.getTime() + (rentalDays * 24L * 60 * 60 * 1000));

            // Charge Details
            double rentalCharge = dailyRate * rentalDays;
            System.out.print("Enter Penalty Charge (if any): $");
            double penaltyCharge = scanner.nextDouble();
            scanner.nextLine();

            // Payment Details
            System.out.print("Enter Payment Mode (Cash/Card/UPI): ");
            String paymentMode = scanner.nextLine();

            System.out.print("Enter Transaction ID: ");
            String transactionId = scanner.nextLine();

            // Calculate Total
            double totalCharge = rentalCharge + penaltyCharge;

            // Create RentalRecord
            RentalRecord record = new RentalRecord(
                    id, companyName, address, phoneNumber, branchName, locationCode,
                    vehicleType, registrationNumber, dailyRate, customerName,
                    licenseNumber, contactNumber, rentalDate, returnDate, rentalDays,
                    rentalCharge, penaltyCharge, paymentMode, transactionId, totalCharge
            );

            // Display Invoice
            record.displayInvoice();

        } catch (DataException e) {
            System.out.println("\n27206 - ERROR: " + e.getMessage());
        } catch (InputMismatchException e) {
            System.out.println("\n27206 - ERROR: Invalid input format!");
        } catch (Exception e) {
            System.out.println("\n27206 - ERROR: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
