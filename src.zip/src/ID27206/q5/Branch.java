package ID27206.q5;

 class Branch extends Company{
    private String branchName;
    private String locationCode;

    public Branch(int id, String companyName, String address, String phoneNumber,
                  String branchName, String locationCode) throws DataException {
        super(id, companyName, address, phoneNumber);
        if (locationCode == null || locationCode.length() < 3) {
            throw new DataException("Location code must be at least 3 characters");
        }
        this.branchName = branchName;
        this.locationCode = locationCode;
    }

    public String getBranchName() {
        return branchName;
    }

    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) throws DataException {
        if (locationCode == null || locationCode.length() < 3) {
            throw new DataException("Location code must be at least 3 characters");
        }
        this.locationCode = locationCode;
    }
}
