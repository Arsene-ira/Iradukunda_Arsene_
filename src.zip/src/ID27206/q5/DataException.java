package ID27206.q5;

public class DataException extends RuntimeException {
    public DataException(String message) {
        super(message);
    }
}
