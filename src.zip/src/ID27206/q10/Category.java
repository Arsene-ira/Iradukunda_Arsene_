package ID27206.q10;

class Category extends Store {
    private String categoryName;
    private String categoryCode;

    public Category(int id, String storeName, String address, String email,
                    String categoryName, String categoryCode) throws DataException {
        super(id, storeName, address, email);
        if (categoryName == null || categoryName.length() < 3) {
            throw new DataException("Category name must be at least 3 characters");
        }
        if (categoryCode == null || categoryCode.length() < 3) {
            throw new DataException("Category code must be at least 3 characters");
        }
        this.categoryName = categoryName;
        this.categoryCode = categoryCode;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) throws DataException {
        if (categoryName == null || categoryName.length() < 3) {
            throw new DataException("Category name must be at least 3 characters");
        }
        this.categoryName = categoryName;
    }

    public String getCategoryCode() {
        return categoryCode;
    }

    public void setCategoryCode(String categoryCode) throws DataException {
        if (categoryCode == null || categoryCode.length() < 3) {
            throw new DataException("Category code must be at least 3 characters");
        }
        this.categoryCode = categoryCode;
    }
}