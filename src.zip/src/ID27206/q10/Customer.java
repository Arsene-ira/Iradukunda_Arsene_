package ID27206.q10;

public class Customer extends Product{
    private String customerName;
    private String contactNumber;
    private String customerAddress;

    public Customer(int id, String storeName, String address, String email,
                    String categoryName, String categoryCode,
                    String productName, String productCode, double price,
                    String customerName, String contactNumber, String customerAddress) throws DataException {
        super(id, storeName, address, email, categoryName, categoryCode, productName, productCode, price);
        if (customerName == null || customerName.trim().isEmpty()) {
            throw new DataException("Customer name cannot be empty");
        }
        if (contactNumber == null || contactNumber.trim().isEmpty()) {
            throw new DataException("Contact number cannot be empty");
        }
        if (customerAddress == null || customerAddress.trim().isEmpty()) {
            throw new DataException("Customer address cannot be empty");
        }
        this.customerName = customerName;
        this.contactNumber = contactNumber;
        this.customerAddress = customerAddress;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) throws DataException {
        if (customerName == null || customerName.trim().isEmpty()) {
            throw new DataException("Customer name cannot be empty");
        }
        this.customerName = customerName;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) throws DataException {
        if (contactNumber == null || contactNumber.trim().isEmpty()) {
            throw new DataException("Contact number cannot be empty");
        }
        this.contactNumber = contactNumber;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) throws DataException {
        if (customerAddress == null || customerAddress.trim().isEmpty()) {
            throw new DataException("Customer address cannot be empty");
        }
        this.customerAddress = customerAddress;
    }
}
