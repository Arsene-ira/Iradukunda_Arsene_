package ID27206.q10;

import java.time.LocalDateTime;

public class Shipping extends Payment{
    private String shippingAddress;
    private double shippingCost;

    public Shipping(int id, String storeName, String address, String email,
                    String categoryName, String categoryCode,
                    String productName, String productCode, double price,
                    String customerName, String contactNumber, String customerAddress,
                    LocalDateTime orderDate, String orderId,
                    String paymentMethod, String paymentStatus,
                    String shippingAddress, double shippingCost) throws DataException {
        super(id, storeName, address, email, categoryName, categoryCode,
                productName, productCode, price, customerName, contactNumber, customerAddress,
                orderDate, orderId, paymentMethod, paymentStatus);
        if (shippingCost < 0) {
            throw new DataException("Shipping cost must be >= 0");
        }
        this.shippingAddress = shippingAddress;
        this.shippingCost = shippingCost;
    }

    public String getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(String shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    public double getShippingCost() {
        return shippingCost;
    }

    public void setShippingCost(double shippingCost) throws DataException {
        if (shippingCost < 0) {
            throw new DataException("Shipping cost must be >= 0");
        }
        this.shippingCost = shippingCost;
    }
}
