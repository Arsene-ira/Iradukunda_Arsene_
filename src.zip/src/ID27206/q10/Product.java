package ID27206.q10;

public class Product extends Category{
    private String productName;
    private String productCode;
    private double price;

    public Product(int id, String storeName, String address, String email,
                   String categoryName, String categoryCode,
                   String productName, String productCode, double price) throws DataException {
        super(id, storeName, address, email, categoryName, categoryCode);
        if (price <= 0) {
            throw new DataException("Price must be greater than 0");
        }
        this.productName = productName;
        this.productCode = productCode;
        this.price = price;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) throws DataException {
        if (price <= 0) {
            throw new DataException("Price must be greater than 0");
        }
        this.price = price;
    }
}
