package ID27206.q1;

import java.time.LocalDateTime;
class Entity {
    private int id;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;

    public Entity(int id) throws HospitalDataException {
        if (id <= 0) {
            throw new HospitalDataException("ID must be greater than 0 - 27206");
        }
        this.id = id;
        this.createdDate = LocalDateTime.now();
        this.updatedDate = LocalDateTime.now();
    }

    public int getId() { return id; }
    public LocalDateTime getCreatedDate() { return createdDate; }
    public LocalDateTime getUpdatedDate() { return updatedDate; }
    public void setUpdatedDate(LocalDateTime updatedDate) { this.updatedDate = updatedDate; }
}