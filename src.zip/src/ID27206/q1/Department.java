package ID27206.q1;

class Department extends Hospital {
    private String departmentName;
    private String departmentCode;

    public Department(int id, String hospitalName, String address, String phoneNumber, String email,
                      String departmentName, String departmentCode)
            throws HospitalDataException {
        super(id, hospitalName, address, phoneNumber, email);

        if (departmentCode.length() < 3 || !departmentCode.matches("[A-Za-z0-9]+")) {
            throw new HospitalDataException("Department code must be alphanumeric and at least 3 characters - 27206");
        }

        this.departmentName = departmentName;
        this.departmentCode = departmentCode;
    }

    public String getDepartmentName() { return departmentName; }
    public String getDepartmentCode() { return departmentCode; }
}
