package ID27206.q1;
import java.util.regex.Pattern;
import java.util.Scanner;

public class HospitalManagementSystem {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("=".repeat(70));
        System.out.println("           HOSPITAL MANAGEMENT SYSTEM - 27206");
        System.out.println("=".repeat(70));

        try {
            // Entity data
            System.out.println("\n--- ENTITY INFORMATION - 27206 ---");
            int id = getValidInt("Enter Entity ID: ");
            System.out.println("Entity created successfully - 27206\n");

            // Hospital data
            System.out.println("--- HOSPITAL INFORMATION - 27206 ---");
            String hospitalName = getValidString("Enter Hospital Name: ");
            String address = getValidString("Enter Hospital Address: ");
            String hospitalPhone = getValidPhone("Enter Hospital Phone (10 digits): ");
            String hospitalEmail = getValidEmail("Enter Hospital Email: ");
            System.out.println("Hospital created successfully - 27206\n");

            // Department data
            System.out.println("--- DEPARTMENT INFORMATION - 27206 ---");
            String departmentName = getValidString("Enter Department Name: ");
            String departmentCode = getValidCode("Enter Department Code (min 3 alphanumeric): ");
            System.out.println("Department created successfully - 27206\n");

            // Doctor data
            System.out.println("--- DOCTOR INFORMATION - 27206 ---");
            String doctorName = getValidString("Enter Doctor Name: ");
            String specialization = getValidString("Enter Specialization: ");
            String doctorEmail = getValidEmail("Enter Doctor Email: ");
            String doctorPhone = getValidPhone("Enter Doctor Phone (10 digits): ");
            System.out.println("Doctor created successfully - 27206\n");

            // Nurse data
            System.out.println("--- NURSE INFORMATION - 27206 ---");
            String nurseName = getValidString("Enter Nurse Name: ");
            String shift = getValidShift("Enter Shift (Day/Night): ");
            int yearsOfExperience = getValidInt("Enter Years of Experience: ");
            System.out.println("Nurse created successfully - 27206\n");

            // Patient data
            System.out.println("--- PATIENT INFORMATION - 27206 ---");
            String patientName = getValidString("Enter Patient Name: ");
            int age = getValidInt("Enter Patient Age: ");
            String gender = getValidGender("Enter Gender (Male/Female/Other): ");
            String contactNumber = getValidString("Enter Contact Number: ");
            System.out.println("Patient created successfully - 27206\n");

            // Admission data
            System.out.println("--- ADMISSION INFORMATION - 27206 ---");
            String admissionDate = getValidString("Enter Admission Date (YYYY-MM-DD): ");
            String roomNumber = getValidString("Enter Room Number: ");
            double roomCharges = getValidDouble("Enter Room Charges: ");
            System.out.println("Admission created successfully - 27206\n");

            // Treatment data
            System.out.println("--- TREATMENT INFORMATION - 27206 ---");
            String diagnosis = getValidString("Enter Diagnosis: ");
            String treatmentGiven = getValidString("Enter Treatment Given: ");
            double treatmentCost = getValidDouble("Enter Treatment Cost: ");
            System.out.println("Treatment created successfully - 27206\n");

            // Bill data
            System.out.println("--- BILLING INFORMATION - 27206 ---");
            double doctorFee = getValidDouble("Enter Doctor Fee: ");
            double medicineCost = getValidDouble("Enter Medicine Cost: ");
            double totalBill = getValidDouble("Enter Total Bill: ");
            System.out.println("Bill created successfully - 27206\n");

            // Create HospitalRecord object
            HospitalRecords record = new HospitalRecords(
                    id, hospitalName, address, hospitalPhone, hospitalEmail,
                    departmentName, departmentCode,
                    doctorName, specialization, doctorEmail, doctorPhone,
                    nurseName, shift, yearsOfExperience,
                    patientName, age, gender, contactNumber,
                    admissionDate, roomNumber, roomCharges,
                    diagnosis, treatmentGiven, treatmentCost,
                    doctorFee, medicineCost, totalBill
            );

            // Display the complete record
            record.displayRecord();

        } catch (HospitalDataException e) {
            System.err.println("\nValidation Error - 27206: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.err.println("\nInput Error - 27206: Please enter valid numbers");
        } catch (Exception e) {
            System.err.println("\nError - 27206: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }

    private static int getValidInt(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                String input = scanner.nextLine().trim();
                int value = Integer.parseInt(input);
                if (value <= 0) {
                    System.out.println("ERROR - 27206: Value must be greater than 0. Try again.");
                    continue;
                }
                return value;
            } catch (NumberFormatException e) {
                System.out.println("ERROR - 27206: Invalid input. Please enter a valid integer.");
            }
        }
    }

    private static double getValidDouble(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                String input = scanner.nextLine().trim();
                double value = Double.parseDouble(input);
                if (value <= 0) {
                    System.out.println("ERROR - 27206: Value must be greater than 0. Try again.");
                    continue;
                }
                return value;
            } catch (NumberFormatException e) {
                System.out.println("ERROR - 27206: Invalid input. Please enter a valid number.");
            }
        }
    }

    private static String getValidString(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (input.isEmpty()) {
                System.out.println("ERROR - 27206: Input cannot be empty. Try again.");
                continue;
            }
            return input;
        }
    }

    private static String getValidPhone(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (input.matches("\\d{10}")) {
                return input;
            }
            System.out.println("ERROR - 27206: Phone must be exactly 10 digits. Try again.");
        }
    }

    private static String getValidEmail(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (input.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
                return input;
            }
            System.out.println("ERROR - 27206: Invalid email format. Try again.");
        }
    }

    private static String getValidCode(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (input.length() >= 3 && input.matches("[A-Za-z0-9]+")) {
                return input;
            }
            System.out.println("ERROR - 27206: Code must be alphanumeric and at least 3 characters. Try again.");
        }
    }

    private static String getValidShift(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (input.equals("Day") || input.equals("Night")) {
                return input;
            }
            System.out.println("ERROR - 27206: Shift must be 'Day' or 'Night'. Try again.");
        }
    }

    private static String getValidGender(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            if (input.equals("Male") || input.equals("Female") || input.equals("Other")) {
                return input;
            }
            System.out.println("ERROR - 27206: Gender must be 'Male', 'Female', or 'Other'. Try again.");
        }
    }
}