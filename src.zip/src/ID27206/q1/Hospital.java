package ID27206.q1;


import java.util.regex.Pattern;

class Hospital extends Entity {
    private String hospitalName;
    private String address;
    private String phoneNumber;
    private String email;

    public Hospital(int id, String hospitalName, String address, String phoneNumber, String email)
            throws HospitalDataException {
        super(id);

        if (!phoneNumber.matches("\\d{10}")) {
            throw new HospitalDataException("Phone number must be exactly 10 digits - 27206");
        }
        if (!isValidEmail(email)) {
            throw new HospitalDataException("Invalid email format - 27206");
        }

        this.hospitalName = hospitalName;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        return Pattern.matches(emailRegex, email);
    }

    public String getHospitalName() { return hospitalName; }
    public String getAddress() { return address; }
    public String getPhoneNumber() { return phoneNumber; }
    public String getEmail() { return email; }
}
