package ID27206.q1;

import java.time.format.DateTimeFormatter;

final class HospitalRecords extends Bill {

    public HospitalRecords(int id, String hospitalName, String address, String phoneNumber, String email,
                          String departmentName, String departmentCode,
                          String doctorName, String specialization, String doctorEmail, String phone,
                          String nurseName, String shift, int yearsOfExperience,
                          String patientName, int age, String gender, String contactNumber,
                          String admissionDate, String roomNumber, double roomCharges,
                          String diagnosis, String treatmentGiven, double treatmentCost,
                          double doctorFee, double medicineCost, double totalBill)
            throws HospitalDataException {
        super(id, hospitalName, address, phoneNumber, email,
                departmentName, departmentCode, doctorName, specialization, doctorEmail, phone,
                nurseName, shift, yearsOfExperience, patientName, age, gender, contactNumber,
                admissionDate, roomNumber, roomCharges, diagnosis, treatmentGiven, treatmentCost,
                doctorFee, medicineCost, totalBill);
    }

    public double generateBill() {
        return getRoomCharges() + getTreatmentCost() + getDoctorFee() + getMedicineCost();
    }

    public void displayRecord() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        System.out.println("\n" + "=".repeat(70));
        System.out.println("         HOSPITAL MANAGEMENT SYSTEM - PATIENT RECORD - 27206");
        System.out.println("=".repeat(70));

        System.out.println("\n--- HOSPITAL INFORMATION - 27206 ---");
        System.out.println("Hospital Name: " + getHospitalName() + " - 27206");
        System.out.println("Address: " + getAddress() + " - 27206");
        System.out.println("Phone: " + getPhoneNumber() + " - 27206");
        System.out.println("Email: " + getEmail() + " - 27206");

        System.out.println("\n--- DEPARTMENT INFORMATION - 27206 ---");
        System.out.println("Department Name: " + getDepartmentName() + " - 27206");
        System.out.println("Department Code: " + getDepartmentCode() + " - 27206");

        System.out.println("\n--- DOCTOR INFORMATION - 27206 ---");
        System.out.println("Doctor Name: " + getDoctorName() + " - 27206");
        System.out.println("Specialization: " + getSpecialization() + " - 27206");
        System.out.println("Email: " + getDoctorEmail() + " - 27206");
        System.out.println("Phone: " + getPhone() + " - 27206");

        System.out.println("\n--- NURSE INFORMATION - 27206 ---");
        System.out.println("Nurse Name: " + getNurseName() + " - 27206");
        System.out.println("Shift: " + getShift() + " - 27206");
        System.out.println("Years of Experience: " + getYearsOfExperience() + " - 27206");

        System.out.println("\n--- PATIENT INFORMATION - 27206 ---");
        System.out.println("Patient Name: " + getPatientName() + " - 27206");
        System.out.println("Age: " + getAge() + " - 27206");
        System.out.println("Gender: " + getGender() + " - 27206");
        System.out.println("Contact Number: " + getContactNumber() + " - 27206");

        System.out.println("\n--- ADMISSION INFORMATION - 27206 ---");
        System.out.println("Admission Date: " + getAdmissionDate() + " - 27206");
        System.out.println("Room Number: " + getRoomNumber() + " - 27206");
        System.out.printf("Room Charges: $%.2f - 27206%n", getRoomCharges());

        System.out.println("\n--- TREATMENT INFORMATION - 27206 ---");
        System.out.println("Diagnosis: " + getDiagnosis() + " - 27206");
        System.out.println("Treatment Given: " + getTreatmentGiven() + " - 27206");
        System.out.printf("Treatment Cost: $%.2f - 27206%n", getTreatmentCost());

        System.out.println("\n--- BILLING INFORMATION - 27206 ---");
        System.out.printf("Doctor Fee: $%.2f - 27206%n", getDoctorFee());
        System.out.printf("Medicine Cost: $%.2f - 27206%n", getMedicineCost());
        System.out.printf("Room Charges: $%.2f - 27206%n", getRoomCharges());
        System.out.printf("Treatment Cost: $%.2f - 27206%n", getTreatmentCost());

        System.out.println("\n" + "=".repeat(70));
        System.out.printf("FINAL COMPUTED BILL: $%.2f - 27206%n", generateBill());
        System.out.println("=".repeat(70));

        System.out.println("\n--- ENTITY METADATA - 27206 ---");
        System.out.println("Record ID: " + getId() + " - 27206");
        System.out.println("Created Date: " + getCreatedDate().format(formatter) + " - 27206");
        System.out.println("Updated Date: " + getUpdatedDate().format(formatter) + " - 27206");
        System.out.println("=".repeat(70));
    }
}
