package ID27206.q3;

final class PayrollRecord extends Salary {

    public PayrollRecord(int id, String createdDate, String updatedDate,
                         String companyName, String address, String phoneNumber, String email,
                         String departmentName, String departmentCode,
                         String managerName, String managerEmail, String managerPhone,
                         String employeeName, int employeeId, String designation, String contactNumber,
                         int totalDays, int presentDays, int leaveDays,
                         double housingAllowance, double transportAllowance,
                         double taxDeduction, double loanDeduction,
                         double basicSalary) throws PayrollDataException {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber, email,
                departmentName, departmentCode, managerName, managerEmail, managerPhone,
                employeeName, employeeId, designation, contactNumber, totalDays, presentDays, leaveDays,
                housingAllowance, transportAllowance, taxDeduction, loanDeduction, basicSalary);
    }

    // Generate Payslip Method
    public void generatePayslip() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("27206 - EMPLOYEE PAYSLIP");
        System.out.println("=".repeat(60));
        System.out.println("Company: " + getCompanyName());
        System.out.println("Address: " + getAddress());
        System.out.println("Contact: " + getPhoneNumber() + " | Email: " + getEmail());
        System.out.println("-".repeat(60));
        System.out.println("EMPLOYEE INFORMATION:");
        System.out.println("Employee Name: " + getEmployeeName());
        System.out.println("Employee ID: " + getEmployeeId() + " | Designation: " + getDesignation());
        System.out.println("Contact: " + getContactNumber());
        System.out.println("-".repeat(60));
        System.out.println("WORK & REPORTING:");
        System.out.println("Department: " + getDepartmentName() + " (" + getDepartmentCode() + ")");
        System.out.println("Manager: " + getManagerName() + " | Manager Contact: " + getManagerPhone());
        System.out.println("Attendance: Total Days = " + getTotalDays() + ", Present = " + getPresentDays() + ", Leave = " + getLeaveDays());
        System.out.println("-".repeat(60));
        System.out.println("SALARY BREAKDOWN:");
        System.out.printf("Basic Salary:        %.2f%n", getBasicSalary());
        System.out.printf("Housing Allowance:   %.2f%n", getHousingAllowance());
        System.out.printf("Transport Allowance: %.2f%n", getTransportAllowance());
        System.out.printf("GROSS SALARY:        %.2f%n", getGrossSalary());
        System.out.println("-".repeat(60));
        System.out.printf("Tax Deduction:       %.2f%n", getTaxDeduction());
        System.out.printf("Loan Deduction:      %.2f%n", getLoanDeduction());
        System.out.println("-".repeat(60));
        System.out.printf("NET SALARY:          %.2f%n", getNetSalary());
        System.out.println("=".repeat(60));
        System.out.println("Student ID: 27206");
        System.out.println("=".repeat(60));
    }
}
