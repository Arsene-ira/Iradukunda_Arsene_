package ID27206.q3;


class PayrollDataException extends Exception {
    public PayrollDataException(String message) {
        super(message);
    }
}
