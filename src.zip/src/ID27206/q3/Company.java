package ID27206.q3;

import java.util.regex.Pattern;

class Company extends Entity {
    private String companyName;
    private String address;
    private String phoneNumber;
    private String email;

    public Company(int id, String createdDate, String updatedDate,
                   String companyName, String address, String phoneNumber, String email)
            throws PayrollDataException {
        super(id, createdDate, updatedDate);

        if (companyName == null || companyName.isEmpty()) {
            throw new PayrollDataException("Company name cannot be null or empty");
        }
        if (address == null || address.isEmpty()) {
            throw new PayrollDataException("Address cannot be null or empty");
        }
        if (phoneNumber == null || phoneNumber.length() != 10 || !phoneNumber.matches("\\d+")) {
            throw new PayrollDataException("Phone number must be exactly 10 digits");
        }
        if (!isValidEmail(email)) {
            throw new PayrollDataException("Invalid email format");
        }

        this.companyName = companyName;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        return email != null && Pattern.matches(emailRegex, email);
    }

    public String getCompanyName() { return companyName; }
    public String getAddress() { return address; }
    public String getPhoneNumber() { return phoneNumber; }
    public String getEmail() { return email; }
}


