package ID27206.q3;

import java.util.regex.Pattern;

class Manager extends Department {
    private String managerName;
    private String managerEmail;
    private String managerPhone;

    public Manager(int id, String createdDate, String updatedDate,
                   String companyName, String address, String phoneNumber, String email,
                   String departmentName, String departmentCode,
                   String managerName, String managerEmail, String managerPhone) throws PayrollDataException {
        super(id, createdDate, updatedDate, companyName, address, phoneNumber, email, departmentName, departmentCode);

        if (managerName == null || managerName.isEmpty()) {
            throw new PayrollDataException("Manager name cannot be null or empty");
        }
        if (!isValidEmail(managerEmail)) {
            throw new PayrollDataException("Invalid manager email format");
        }
        if (managerPhone == null || managerPhone.length() != 10 || !managerPhone.matches("\\d+")) {
            throw new PayrollDataException("Manager phone must be exactly 10 digits");
        }

        this.managerName = managerName;
        this.managerEmail = managerEmail;
        this.managerPhone = managerPhone;
    }

    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        return email != null && Pattern.matches(emailRegex, email);
    }

    public String getManagerName() { return managerName; }
    public String getManagerEmail() { return managerEmail; }
    public String getManagerPhone() { return managerPhone; }
}
