package ID27206.q2;

import java.util.Scanner;

public class SchoolManagementSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.println("=== SCHOOL MANAGEMENT SYSTEM ===");
            System.out.println("Student ID: 27206\n");

            // Entity Information
            System.out.print("Enter Record ID: ");
            int id = sc.nextInt();
            sc.nextLine();
            System.out.print("Enter Created Date (DD-MM-YYYY): ");
            String createdDate = sc.nextLine();
            System.out.print("Enter Updated Date (DD-MM-YYYY): ");
            String updatedDate = sc.nextLine();

            // School Information
            System.out.print("\nEnter School Name: ");
            String schoolName = sc.nextLine();
            System.out.print("Enter Address: ");
            String address = sc.nextLine();
            System.out.print("Enter Phone Number (10 digits): ");
            String phoneNumber = sc.nextLine();
            System.out.print("Enter Email: ");
            String email = sc.nextLine();

            // Department Information
            System.out.print("\nEnter Department Name: ");
            String departmentName = sc.nextLine();
            System.out.print("Enter Department Code (alphanumeric, min 3 chars): ");
            String departmentCode = sc.nextLine();

            // Teacher Information
            System.out.print("\nEnter Teacher Name: ");
            String teacherName = sc.nextLine();
            System.out.print("Enter Subject: ");
            String subject = sc.nextLine();
            System.out.print("Enter Teacher Email: ");
            String teacherEmail = sc.nextLine();
            System.out.print("Enter Teacher Phone (10 digits): ");
            String teacherPhone = sc.nextLine();

            // Student Information
            System.out.print("\nEnter Student Name: ");
            String studentName = sc.nextLine();
            System.out.print("Enter Roll Number: ");
            int rollNumber = sc.nextInt();
            sc.nextLine();
            System.out.print("Enter Grade: ");
            String grade = sc.nextLine();
            System.out.print("Enter Contact Number: ");
            String contactNumber = sc.nextLine();

            // Course Information
            System.out.print("\nEnter Course Name: ");
            String courseName = sc.nextLine();
            System.out.print("Enter Course Code: ");
            String courseCode = sc.nextLine();
            System.out.print("Enter Credit Hours: ");
            int creditHours = sc.nextInt();
            sc.nextLine();

            // Exam Information
            System.out.print("\nEnter Exam Name: ");
            String examName = sc.nextLine();
            System.out.print("Enter Maximum Marks: ");
            int maxMarks = sc.nextInt();
            sc.nextLine();
            System.out.print("Enter Exam Date (DD-MM-YYYY): ");
            String examDate = sc.nextLine();

            // Result Information
            System.out.print("\nEnter Obtained Marks: ");
            int obtainedMarks = sc.nextInt();
            sc.nextLine();
            System.out.print("Enter Remarks: ");
            String remarks = sc.nextLine();

            // Fee Information
            System.out.print("\nEnter Tuition Fee: ");
            double tuitionFee = sc.nextDouble();
            System.out.print("Enter Exam Fee: ");
            double examFee = sc.nextDouble();

            // Create StudentRecord and Calculate Average
            StudentRecord record = new StudentRecord(id, createdDate, updatedDate, schoolName,
                    address, phoneNumber, email, departmentName, departmentCode, teacherName,
                    subject, teacherEmail, teacherPhone, studentName, rollNumber, grade,
                    contactNumber, courseName, courseCode, creditHours, examName, maxMarks,
                    examDate, obtainedMarks, remarks, tuitionFee, examFee);

            record.calculateAverageMarks();

        } catch (SchoolDataException e) {
            System.out.println("\n27206 - ERROR: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("\n27206 - ERROR: Invalid input format. " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}
