package ID27206.q2;

public class StudentRecord extends Fee{
    private double averageMarks;

    public StudentRecord(int id, String createdDate, String updatedDate, String schoolName,
                         String address, String phoneNumber, String email, String departmentName,
                         String departmentCode, String teacherName, String subject,
                         String teacherEmail, String phone, String studentName, int rollNumber,
                         String grade, String contactNumber, String courseName, String courseCode,
                         int creditHours, String examName, int maxMarks, String examDate,
                         int obtainedMarks, String remarks, double tuitionFee, double examFee)
            throws SchoolDataException {
        super(id, createdDate, updatedDate, schoolName, address, phoneNumber, email,
                departmentName, departmentCode, teacherName, subject, teacherEmail, phone,
                studentName, rollNumber, grade, contactNumber, courseName, courseCode,
                creditHours, examName, maxMarks, examDate, obtainedMarks, remarks,
                tuitionFee, examFee);
        this.averageMarks = 0; // Will be calculated
    }

    public double getAverageMarks() { return averageMarks; }

    // Calculate Average Marks Method
    public void calculateAverageMarks() {
        this.averageMarks = ((double) getObtainedMarks() / getMaxMarks()) * 100;
        setTotalFee(getTuitionFee() + getExamFee());

        System.out.println("\n" + "=".repeat(70));
        System.out.println("27206 - STUDENT ACADEMIC & FEE RECORD");
        System.out.println("=".repeat(70));
        System.out.println("School: " + getSchoolName());
        System.out.println("Address: " + getAddress());
        System.out.println("Contact: " + getPhoneNumber() + " | Email: " + getEmail());
        System.out.println("-".repeat(70));
        System.out.println("STUDENT INFORMATION:");
        System.out.println("Student Name: " + getStudentName());
        System.out.println("Roll Number: " + getRollNumber());
        System.out.println("Grade: " + getGrade());
        System.out.println("Contact Number: " + getContactNumber());
        System.out.println("-".repeat(70));
        System.out.println("ACADEMIC DETAILS:");
        System.out.println("Department: " + getDepartmentName() + " (" + getDepartmentCode() + ")");
        System.out.println("Course: " + getCourseName() + " (" + getCourseCode() + ")");
        System.out.println("Credit Hours: " + getCreditHours());
        System.out.println("Teacher: " + getTeacherName());
        System.out.println("Subject: " + getSubject());
        System.out.println("Teacher Email: " + getTeacherEmail());
        System.out.println("Teacher Phone: " + getPhone());
        System.out.println("-".repeat(70));
        System.out.println("EXAMINATION RESULTS:");
        System.out.println("Exam Name: " + getExamName());
        System.out.println("Exam Date: " + getExamDate());
        System.out.println("Maximum Marks: " + getMaxMarks());
        System.out.println("Obtained Marks: " + getObtainedMarks());
        System.out.printf("Average/Percentage: %.2f%%%n", averageMarks);
        System.out.println("Remarks: " + getRemarks());

        // Grade Status
        String status;
        if (averageMarks >= 90) status = "Outstanding (A+)";
        else if (averageMarks >= 80) status = "Excellent (A)";
        else if (averageMarks >= 70) status = "Very Good (B+)";
        else if (averageMarks >= 60) status = "Good (B)";
        else if (averageMarks >= 50) status = "Average (C)";
        else if (averageMarks >= 40) status = "Pass (D)";
        else status = "Fail (F)";

        System.out.println("Grade Status: " + status);
        System.out.println("-".repeat(70));
        System.out.println("FEE DETAILS:");
        System.out.printf("Tuition Fee:      Rs. %.2f%n", getTuitionFee());
        System.out.printf("Exam Fee:         Rs. %.2f%n", getExamFee());
        System.out.println("-".repeat(70));
        System.out.printf("TOTAL FEE:        Rs. %.2f%n", getTotalFee());
        System.out.println("=".repeat(70));
        System.out.println("Record ID: " + getId());
        System.out.println("Created: " + getCreatedDate() + " | Updated: " + getUpdatedDate());
        System.out.println("Student ID: 27206");
        System.out.println("=".repeat(70));
    }
}
