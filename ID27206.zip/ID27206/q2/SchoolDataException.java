package ID27206.q2;

class SchoolDataException extends Exception {
    public SchoolDataException(String message) {
        super(message);
    }
}