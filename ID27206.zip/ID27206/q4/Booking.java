package ID27206.q4;

import java.time.LocalDate;

public class Booking extends Customer {
    private LocalDate bookingDate;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;

    public Booking(int id, String hotelName, String address, String phoneNumber, String email,
                   String roomNumber, String roomType, double pricePerNight,
                   String customerName, String customerEmail, String contactNumber,
                   LocalDate bookingDate, LocalDate checkInDate, LocalDate checkOutDate) throws DataException {
        super(id, hotelName, address, phoneNumber, email, roomNumber, roomType, pricePerNight,
                customerName, customerEmail, contactNumber);
        if (bookingDate == null || checkInDate == null || checkOutDate == null) {
            throw new DataException("Dates cannot be null");
        }
        if (checkOutDate.isBefore(checkInDate)) {
            throw new DataException("Check-out date must be after check-in date");
        }
        this.bookingDate = bookingDate;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }

    public LocalDate getBookingDate() { return bookingDate; }
    public void setBookingDate(LocalDate bookingDate) throws DataException {
        if (bookingDate == null) {
            throw new DataException("Booking date cannot be null");
        }
        this.bookingDate = bookingDate;
    }

    public LocalDate getCheckInDate() { return checkInDate; }
    public void setCheckInDate(LocalDate checkInDate) throws DataException {
        if (checkInDate == null) {
            throw new DataException("Check-in date cannot be null");
        }
        this.checkInDate = checkInDate;
    }

    public LocalDate getCheckOutDate() { return checkOutDate; }
    public void setCheckOutDate(LocalDate checkOutDate) throws DataException {
        if (checkOutDate == null) {
            throw new DataException("Check-out date cannot be null");
        }
        if (checkOutDate.isBefore(checkInDate)) {
            throw new DataException("Check-out date must be after check-in date");
        }
        this.checkOutDate = checkOutDate;
    }

    public long getNumberOfNights() {
        return java.time.temporal.ChronoUnit.DAYS.between(checkInDate, checkOutDate);
    }
}
