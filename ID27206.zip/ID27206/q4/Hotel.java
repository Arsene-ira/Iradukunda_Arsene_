package ID27206.q4;

public class Hotel extends Entity{
    private String hotelName;
    private String address;
    private String phoneNumber;
    private String email;

    public Hotel(int id, String hotelName, String address, String phoneNumber, String email) throws DataException {
        super(id);
        if (hotelName == null || hotelName.trim().isEmpty()) {
            throw new DataException("Hotel name cannot be empty");
        }
        if (!isValidEmail(email)) {
            throw new DataException("Invalid email format");
        }
        if (!isValidPhone(phoneNumber)) {
            throw new DataException("Invalid phone number format");
        }
        this.hotelName = hotelName;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    private boolean isValidEmail(String email) {
        return email != null && email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    }

    private boolean isValidPhone(String phone) {
        return phone != null && phone.matches("^[0-9]{10,15}$");
    }

    public String getHotelName() { return hotelName; }
    public void setHotelName(String hotelName) throws DataException {
        if (hotelName == null || hotelName.trim().isEmpty()) {
            throw new DataException("Hotel name cannot be empty");
        }
        this.hotelName = hotelName;
    }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) throws DataException {
        if (!isValidPhone(phoneNumber)) {
            throw new DataException("Invalid phone number format");
        }
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() { return email; }
    public void setEmail(String email) throws DataException {
        if (!isValidEmail(email)) {
            throw new DataException("Invalid email format");
        }
        this.email = email;
    }
}
