package ID27206.q4;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class HotelReservationSystem {
    private static Scanner scanner = new Scanner(System.in);
    private static DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static void main(String[] args) {
        System.out.println("27206 - Hotel Reservation System - 27206");
        System.out.println("═══════════════════════════════════════════\n");

        try {
            // Booking ID
            int id = getValidIntInput("27206 - Enter Booking ID: ");

            // Hotel Details
            System.out.println("\n27206 - HOTEL INFORMATION - 27206");
            String hotelName = getValidStringInput("27206 - Enter Hotel Name: ");
            String address = getValidStringInput("27206 - Enter Hotel Address: ");
            String hotelPhone = getValidPhoneInput("27206 - Enter Hotel Phone (10-15 digits): ");
            String hotelEmail = getValidEmailInput("27206 - Enter Hotel Email: ");

            // Room Details
            System.out.println("\n27206 - ROOM INFORMATION - 27206");
            String roomNumber = getValidStringInput("27206 - Enter Room Number: ");
            String roomType = getValidStringInput("27206 - Enter Room Type (e.g., Single/Double/Suite): ");
            double pricePerNight = getValidDoubleInput("27206 - Enter Price Per Night: $");

            // Customer Details
            System.out.println("\n27206 - CUSTOMER INFORMATION - 27206");
            String customerName = getValidStringInput("27206 - Enter Customer Name: ");
            String customerEmail = getValidEmailInput("27206 - Enter Customer Email: ");
            String contactNumber = getValidPhoneInput("27206 - Enter Contact Number (10-15 digits): ");

            // Booking Dates
            System.out.println("\n27206 - BOOKING DATES - 27206");
            LocalDate bookingDate = getValidDateInput("27206 - Enter Booking Date (yyyy-MM-dd): ");
            LocalDate checkInDate = getValidDateInput("27206 - Enter Check-In Date (yyyy-MM-dd): ");
            LocalDate checkOutDate = getValidDateInput("27206 - Enter Check-Out Date (yyyy-MM-dd): ");

            // Service Details
            System.out.println("\n27206 - SERVICE INFORMATION - 27206");
            String serviceName = getValidStringInput("27206 - Enter Service Name (e.g., Breakfast/Spa/None): ");
            double serviceCost = getValidDoubleInput("27206 - Enter Service Cost: $");

            // Payment Details
            System.out.println("\n27206 - PAYMENT INFORMATION - 27206");
            String paymentMethod = getValidStringInput("27206 - Enter Payment Method (Cash/Card/UPI): ");
            LocalDate paymentDate = getValidDateInput("27206 - Enter Payment Date (yyyy-MM-dd): ");

            // Feedback
            System.out.println("\n27206 - FEEDBACK - 27206");
            int rating = getValidRatingInput("27206 - Enter Rating (1-5): ");
            String comments = getValidStringInput("27206 - Enter Comments: ");

            // Create Reservation Record
            ReservationRecord record = new ReservationRecord(
                    id, hotelName, address, hotelPhone, hotelEmail,
                    roomNumber, roomType, pricePerNight,
                    customerName, customerEmail, contactNumber,
                    bookingDate, checkInDate, checkOutDate,
                    serviceName, serviceCost,
                    paymentMethod, paymentDate,
                    rating, comments
            );

            // Display Invoice
            record.displayInvoice();

        } catch (DataException e) {
            System.out.println("27206 - ERROR: " + e.getMessage() + " - 27206");
        } catch (Exception e) {
            System.out.println("27206 - SYSTEM ERROR: " + e.getMessage() + " - 27206");
        } finally {
            scanner.close();
        }
    }

    private static int getValidIntInput(String prompt) throws DataException {
        while (true) {
            try {
                System.out.print(prompt);
                int value = Integer.parseInt(scanner.nextLine().trim());
                if (value <= 0) {
                    throw new DataException("Value must be greater than 0");
                }
                return value;
            } catch (NumberFormatException e) {
                System.out.println("27206 - Invalid input. Please enter a valid number. - 27206");
            } catch (DataException e) {
                System.out.println("27206 - " + e.getMessage() + " - 27206");
            }
        }
    }

    private static double getValidDoubleInput(String prompt) throws DataException {
        while (true) {
            try {
                System.out.print(prompt);
                double value = Double.parseDouble(scanner.nextLine().trim());
                if (value < 0) {
                    throw new DataException("Value must be greater than or equal to 0");
                }
                return value;
            } catch (NumberFormatException e) {
                System.out.println("27206 - Invalid input. Please enter a valid number. - 27206");
            } catch (DataException e) {
                System.out.println("27206 - " + e.getMessage() + " - 27206");
            }
        }
    }

    private static String getValidStringInput(String prompt) throws DataException {
        while (true) {
            System.out.print(prompt);
            String value = scanner.nextLine().trim();
            if (value.isEmpty()) {
                System.out.println("27206 - Input cannot be empty. Please try again. - 27206");
            } else {
                return value;
            }
        }
    }

    private static String getValidEmailInput(String prompt) throws DataException {
        while (true) {
            System.out.print(prompt);
            String email = scanner.nextLine().trim();
            if (email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")) {
                return email;
            }
            System.out.println("27206 - Invalid email format. Please try again. - 27206");
        }
    }

    private static String getValidPhoneInput(String prompt) throws DataException {
        while (true) {
            System.out.print(prompt);
            String phone = scanner.nextLine().trim();
            if (phone.matches("^[0-9]{10,15}$")) {
                return phone;
            }
            System.out.println("27206 - Invalid phone number. Must be 10-15 digits. - 27206");
        }
    }

    private static LocalDate getValidDateInput(String prompt) throws DataException {
        while (true) {
            try {
                System.out.print(prompt);
                String dateStr = scanner.nextLine().trim();
                return LocalDate.parse(dateStr, dateFormatter);
            } catch (DateTimeParseException e) {
                System.out.println("27206 - Invalid date format. Use yyyy-MM-dd. - 27206");
            }
        }
    }

    private static int getValidRatingInput(String prompt) throws DataException {
        while (true) {
            try {
                System.out.print(prompt);
                int rating = Integer.parseInt(scanner.nextLine().trim());
                if (rating >= 1 && rating <= 5) {
                    return rating;
                }
                System.out.println("27206 - Rating must be between 1 and 5. - 27206");
            } catch (NumberFormatException e) {
                System.out.println("27206 - Invalid input. Please enter a number between 1 and 5. - 27206");
            }
        }
    }
}