package ID27206.q4;

public class Customer extends Room{
    private String customerName;
    private String customerEmail;
    private String contactNumber;

    public Customer(int id, String hotelName, String address, String phoneNumber, String email,
                    String roomNumber, String roomType, double pricePerNight,
                    String customerName, String customerEmail, String contactNumber) throws DataException {
        super(id, hotelName, address, phoneNumber, email, roomNumber, roomType, pricePerNight);
        if (customerName == null || customerName.trim().isEmpty()) {
            throw new DataException("Customer name cannot be empty");
        }
        if (!isValidEmail(customerEmail)) {
            throw new DataException("Invalid customer email format");
        }
        if (!isValidPhone(contactNumber)) {
            throw new DataException("Invalid contact number format");
        }
        this.customerName = customerName;
        this.customerEmail = customerEmail;
        this.contactNumber = contactNumber;
    }

    private boolean isValidEmail(String email) {
        return email != null && email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    }

    private boolean isValidPhone(String phone) {
        return phone != null && phone.matches("^[0-9]{10,15}$");
    }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) throws DataException {
        if (customerName == null || customerName.trim().isEmpty()) {
            throw new DataException("Customer name cannot be empty");
        }
        this.customerName = customerName;
    }

    public String getCustomerEmail() { return customerEmail; }
    public void setCustomerEmail(String customerEmail) throws DataException {
        if (!isValidEmail(customerEmail)) {
            throw new DataException("Invalid customer email format");
        }
        this.customerEmail = customerEmail;
    }

    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) throws DataException {
        if (!isValidPhone(contactNumber)) {
            throw new DataException("Invalid contact number format");
        }
        this.contactNumber = contactNumber;
    }
}
