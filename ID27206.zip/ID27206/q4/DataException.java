package ID27206.q4;

public class DataException extends RuntimeException {
    public DataException(String message) {
        super("27206 " +message);
    }
}
