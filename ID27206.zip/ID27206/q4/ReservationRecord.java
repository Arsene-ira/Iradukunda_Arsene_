package ID27206.q4;

import java.time.LocalDate;

public class ReservationRecord extends Feedback {
    public ReservationRecord(int id, String hotelName, String address, String phoneNumber, String email,
                             String roomNumber, String roomType, double pricePerNight,
                             String customerName, String customerEmail, String contactNumber,
                             LocalDate bookingDate, LocalDate checkInDate, LocalDate checkOutDate,
                             String serviceName, double serviceCost,
                             String paymentMethod, LocalDate paymentDate,
                             int rating, String comments) throws DataException {
        super(id, hotelName, address, phoneNumber, email, roomNumber, roomType, pricePerNight,
                customerName, customerEmail, contactNumber, bookingDate, checkInDate, checkOutDate,
                serviceName, serviceCost, paymentMethod, paymentDate, rating, comments);
    }

    public void displayInvoice() {
        String invoice = "\n" +
                "═══════════════════════════════════════════════════════════\n" +
                "              HOTEL RESERVATION INVOICE - 27206            \n" +
                "═══════════════════════════════════════════════════════════\n" +
                "Booking ID: " + getId() + " - 27206\n" +
                "Hotel: " + getHotelName() + " - 27206\n" +
                "Address: " + getAddress() + " - 27206\n" +
                "Contact: " + getPhoneNumber() + " - 27206\n" +
                "Email: " + getEmail() + " - 27206\n" +
                "-----------------------------------------------------------\n" +
                "CUSTOMER DETAILS - 27206\n" +
                "Name: " + getCustomerName() + " - 27206\n" +
                "Email: " + getCustomerEmail() + " - 27206\n" +
                "Contact: " + getContactNumber() + " - 27206\n" +
                "-----------------------------------------------------------\n" +
                "ROOM DETAILS - 27206\n" +
                "Room Number: " + getRoomNumber() + " - 27206\n" +
                "Room Type: " + getRoomType() + " - 27206\n" +
                "Price Per Night: $" + String.format("%.2f", getPricePerNight()) + " - 27206\n" +
                "-----------------------------------------------------------\n" +
                "BOOKING DETAILS - 27206\n" +
                "Booking Date: " + getBookingDate() + " - 27206\n" +
                "Check-In Date: " + getCheckInDate() + " - 27206\n" +
                "Check-Out Date: " + getCheckOutDate() + " - 27206\n" +
                "Number of Nights: " + getNumberOfNights() + " - 27206\n" +
                "-----------------------------------------------------------\n" +
                "SERVICE DETAILS - 27206\n" +
                "Service: " + getServiceName() + " - 27206\n" +
                "Service Cost: $" + String.format("%.2f", getServiceCost()) + " - 27206\n" +
                "-----------------------------------------------------------\n" +
                "PAYMENT DETAILS - 27206\n" +
                "Payment Method: " + getPaymentMethod() + " - 27206\n" +
                "Payment Date: " + getPaymentDate() + " - 27206\n" +
                "-----------------------------------------------------------\n" +
                "BILLING SUMMARY - 27206\n" +
                "Room Charges: $" + String.format("%.2f", getRoomCharge()) + " - 27206\n" +
                "Service Charges: $" + String.format("%.2f", getServiceCharge()) + " - 27206\n" +
                "TOTAL BILL: $" + String.format("%.2f", getTotalBill()) + " - 27206\n" +
                "-----------------------------------------------------------\n" +
                "FEEDBACK - 27206\n" +
                "Rating: " + getRating() + "/5 - 27206\n" +
                "Comments: " + getComments() + " - 27206\n" +
                "═══════════════════════════════════════════════════════════\n" +
                "       Thank you for choosing our hotel! - 27206          \n" +
                "═══════════════════════════════════════════════════════════\n";

        System.out.println(invoice);
    }

}
