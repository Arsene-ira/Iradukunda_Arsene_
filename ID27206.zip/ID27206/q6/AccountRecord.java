package ID27206.q6;

final class AccountRecord extends Payment{
    private Loan loan;

    public AccountRecord(int id, String bankName, String branchCode, String address, String accountNumber, String accountType, double balance, String customerName, String email, String phoneNumber, String transactionId, String transactionType, double amount, double paymentAmount) throws DataException {
        super(id, bankName, branchCode, address, accountNumber, accountType, balance, customerName, email, phoneNumber, transactionId, transactionType, amount, paymentAmount);
    }




    public final double calculateInterest() {
        return (loan.getLoanAmount() * loan.getInterestRate() * loan.getDuration()) / 100;
    }

    public Loan getLoan() {
        return loan;
    }

    public void setLoan(Loan loan) {
        this.loan = loan;
    }
}
