package ID27206.q6;
import java.util.*;

 class Entity {
     private int id;
     private Date createdDate;
     private Date updatedDate;

     public Entity(int id) throws DataException {
         if (id <= 0) {
             throw new DataException("ID must be greater than 0");
         }
         this.id = id;
         this.createdDate = new Date();
         this.updatedDate = new Date();
     }

     public int getId() {
         return id;
     }

     public void setId(int id) throws DataException {
         if (id <= 0) {
             throw new DataException("ID must be greater than 0");
         }
         this.id = id;
         this.updatedDate = new Date();
     }

     public Date getCreatedDate() {
         return createdDate;
     }

     public Date getUpdatedDate() {
         return updatedDate;
     }

     public void setUpdatedDate(Date updatedDate) {
         this.updatedDate = updatedDate;
     }
}
