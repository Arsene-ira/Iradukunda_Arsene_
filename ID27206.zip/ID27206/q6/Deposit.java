package ID27206.q6;
import java.util.Date;

public class Deposit extends Transaction{
    private double depositAmount;
    private Date depositDate;

    public Deposit(int id, String bankName, String branchCode, String address,
                   String accountNumber, String accountType, double balance,
                   String customerName, String email, String phoneNumber,
                   String transactionId, String transactionType, double amount) throws DataException {
        super(id, bankName, branchCode, address, accountNumber, accountType, balance,
                customerName, email, phoneNumber, transactionId, transactionType, amount);
        if (depositAmount <= 0) {
            throw new DataException("Deposit amount must be greater than 0");
        }
        this.depositAmount = depositAmount;
        this.depositDate = new Date();
    }



    public double getDepositAmount() {
        return depositAmount;
    }

    public void setDepositAmount(double depositAmount) throws DataException {
        if (depositAmount <= 0) {
            throw new DataException("Deposit amount must be greater than 0");
        }
        this.depositAmount = depositAmount;
    }

    public Date getDepositDate() {
        return depositDate;
    }

    public void setDepositDate(Date depositDate) {
        this.depositDate = depositDate;
    }
}
