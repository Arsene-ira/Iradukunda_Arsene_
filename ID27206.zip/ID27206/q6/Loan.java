package ID27206.q6;

public class Loan extends Withdrawal{
    private double loanAmount;
    private double interestRate;
    private int duration;

    public Loan(int id, String bankName, String branchCode, String address,
                String accountNumber, String accountType, double balance,
                String customerName, String email, String phoneNumber,
                String transactionId, String transactionType, double amount,
                double loanAmount, double interestRate, int duration) throws DataException {
        super(id, bankName, branchCode, address, accountNumber, accountType, balance,
                customerName, email, phoneNumber, transactionId, transactionType, amount);
        if (loanAmount <= 0 || interestRate <= 0 || duration <= 0) {
            throw new DataException("Loan amount, interest rate, and duration must all be greater than 0");
        }
        this.loanAmount = loanAmount;
        this.interestRate = interestRate;
        this.duration = duration;
    }

        public Loan(int id, String bankName, String branchCode, String address, String accountNumber, String accountType, double balance, String customerName, String email, String phoneNumber, String transactionId, String transactionType, double amount) {
        super(id, bankName, branchCode, address, accountNumber, accountType, balance,
                customerName, email, phoneNumber, transactionId, transactionType, amount);
    }

    public double getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(double loanAmount) throws DataException {
        if (loanAmount <= 0) {
            throw new DataException("Loan amount must be greater than 0");
        }
        this.loanAmount = loanAmount;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) throws DataException {
        if (interestRate <= 0) {
            throw new DataException("Interest rate must be greater than 0");
        }
        this.interestRate = interestRate;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) throws DataException {
        if (duration <= 0) {
            throw new DataException("Duration must be greater than 0");
        }
        this.duration = duration;
    }
}
