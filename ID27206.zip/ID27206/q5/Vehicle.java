package ID27206.q5;

class Vehicle extends Branch{
    private String vehicleType;
    private String registrationNumber;
    private double dailyRate;

    public Vehicle(int id, String companyName, String address, String phoneNumber,
                   String branchName, String locationCode, String vehicleType,
                   String registrationNumber, double dailyRate) throws DataException {
        super(id, companyName, address, phoneNumber, branchName, locationCode);
        if (dailyRate <= 0) {
            throw new DataException("Daily rate must be greater than 0");
        }
        this.vehicleType = vehicleType;
        this.registrationNumber = registrationNumber;
        this.dailyRate = dailyRate;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public double getDailyRate() {
        return dailyRate;
    }

    public void setDailyRate(double dailyRate) throws DataException {
        if (dailyRate <= 0) {
            throw new DataException("Daily rate must be greater than 0");
        }
        this.dailyRate = dailyRate;
    }
}
