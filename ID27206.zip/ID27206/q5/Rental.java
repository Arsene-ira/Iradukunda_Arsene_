package ID27206.q5;
import java.util.*;

 class Rental extends Customer{
    private Date rentalDate;
    private Date returnDate;
    private int rentalDays;

    public Rental(int id, String companyName, String address, String phoneNumber,
                  String branchName, String locationCode, String vehicleType,
                  String registrationNumber, double dailyRate, String customerName,
                  String licenseNumber, String contactNumber, Date rentalDate,
                  Date returnDate, int rentalDays) throws DataException {
        super(id, companyName, address, phoneNumber, branchName, locationCode,
                vehicleType, registrationNumber, dailyRate, customerName,
                licenseNumber, contactNumber);
        if (rentalDays <= 0) {
            throw new DataException("Rental days must be greater than 0");
        }
        this.rentalDate = rentalDate;
        this.returnDate = returnDate;
        this.rentalDays = rentalDays;
    }

    public Date getRentalDate() {
        return rentalDate;
    }

    public void setRentalDate(Date rentalDate) {
        this.rentalDate = rentalDate;
    }

    public Date getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Date returnDate) {
        this.returnDate = returnDate;
    }

    public int getRentalDays() {
        return rentalDays;
    }

    public void setRentalDays(int rentalDays) throws DataException {
        if (rentalDays <= 0) {
            throw new DataException("Rental days must be greater than 0");
        }
        this.rentalDays = rentalDays;
    }
}
