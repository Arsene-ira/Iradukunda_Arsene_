package ID27206.q5;
import java.util.*;


 class Payment extends Charge{
    private String paymentMode;
    private String transactionId;

    public Payment(int id, String companyName, String address, String phoneNumber,
                   String branchName, String locationCode, String vehicleType,
                   String registrationNumber, double dailyRate, String customerName,
                   String licenseNumber, String contactNumber, Date rentalDate,
                   Date returnDate, int rentalDays, double rentalCharge,
                   double penaltyCharge, String paymentMode, String transactionId) throws DataException {
        super(id, companyName, address, phoneNumber, branchName, locationCode,
                vehicleType, registrationNumber, dailyRate, customerName,
                licenseNumber, contactNumber, rentalDate, returnDate, rentalDays,
                rentalCharge, penaltyCharge);
        if (paymentMode == null || paymentMode.trim().isEmpty() ||
                transactionId == null || transactionId.trim().isEmpty()) {
            throw new DataException("Payment mode and transaction ID cannot be empty");
        }
        this.paymentMode = paymentMode;
        this.transactionId = transactionId;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) throws DataException {
        if (paymentMode == null || paymentMode.trim().isEmpty()) {
            throw new DataException("Payment mode cannot be empty");
        }
        this.paymentMode = paymentMode;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) throws DataException {
        if (transactionId == null || transactionId.trim().isEmpty()) {
            throw new DataException("Transaction ID cannot be empty");
        }
        this.transactionId = transactionId;
    }
}
