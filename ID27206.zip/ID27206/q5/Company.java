package ID27206.q5;

 class Company extends Entity{
    private String companyName;
    private String address;
    private String phoneNumber;

    public Company(int id, String companyName, String address, String phoneNumber) throws DataException {
        super(id);
        if (phoneNumber == null || phoneNumber.replaceAll("[^0-9]", "").length() != 10) {
            throw new DataException("Phone number must be exactly 10 digits");
        }
        this.companyName = companyName;
        this.address = address;
        this.phoneNumber = phoneNumber;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) throws DataException {
        if (phoneNumber == null || phoneNumber.replaceAll("[^0-9]", "").length() != 10) {
            throw new DataException("Phone number must be exactly 10 digits");
        }
        this.phoneNumber = phoneNumber;
    }
}
