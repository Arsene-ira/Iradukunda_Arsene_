package ID27206.q8;

import java.time.LocalDate;

public class Record extends Payment{
    private double totalFine;

    public Record(int id, String libraryName, String location, String phoneNumber,
                  String sectionName, String sectionCode,
                  String title, String author, String ISBN,
                  String memberName, int memberId, String contactNumber,
                  LocalDate borrowDate, LocalDate returnDate,
                  double fineAmount, long daysLate,
                  LocalDate paymentDate, String paymentMode,
                  double totalFine) throws DataException {
        super(id, libraryName, location, phoneNumber, sectionName, sectionCode,
                title, author, ISBN, memberName, memberId, contactNumber,
                borrowDate, returnDate, fineAmount, daysLate, paymentDate, paymentMode);
        if (totalFine <= 0) {
            throw new DataException("Total fine must be greater than 0");
        }
        this.totalFine = totalFine;
    }

    public double getTotalFine() { return totalFine; }
    public void setTotalFine(double totalFine) throws DataException {
        if (totalFine <= 0) {
            throw new DataException("Total fine must be greater than 0");
        }
        this.totalFine = totalFine;
    }
}
