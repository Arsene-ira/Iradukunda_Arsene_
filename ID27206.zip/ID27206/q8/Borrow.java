package ID27206.q8;

import java.time.LocalDate;

public class Borrow extends Member{
    private LocalDate borrowDate;
    private LocalDate returnDate;

    public Borrow(int id, String libraryName, String location, String phoneNumber,
                  String sectionName, String sectionCode,
                  String title, String author, String ISBN,
                  String memberName, int memberId, String contactNumber,
                  LocalDate borrowDate, LocalDate returnDate) throws DataException {
        super(id, libraryName, location, phoneNumber, sectionName, sectionCode,
                title, author, ISBN, memberName, memberId, contactNumber);
        if (borrowDate == null || returnDate == null) {
            throw new DataException("Borrow date and return date cannot be empty");
        }
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
    }

    public LocalDate getBorrowDate() { return borrowDate; }
    public void setBorrowDate(LocalDate borrowDate) throws DataException {
        if (borrowDate == null) {
            throw new DataException("Borrow date cannot be empty");
        }
        this.borrowDate = borrowDate;
    }

    public LocalDate getReturnDate() { return returnDate; }
    public void setReturnDate(LocalDate returnDate) throws DataException {
        if (returnDate == null) {
            throw new DataException("Return date cannot be empty");
        }
        this.returnDate = returnDate;
    }
}
