package ID27206.q8;

import java.time.LocalDate;

public class Fine extends Borrow{
    private double fineAmount;
    private long daysLate;

    public Fine(int id, String libraryName, String location, String phoneNumber,
                String sectionName, String sectionCode,
                String title, String author, String ISBN,
                String memberName, int memberId, String contactNumber,
                LocalDate borrowDate, LocalDate returnDate,
                double fineAmount, long daysLate) throws DataException {
        super(id, libraryName, location, phoneNumber, sectionName, sectionCode,
                title, author, ISBN, memberName, memberId, contactNumber,
                borrowDate, returnDate);
        if (fineAmount < 0) {
            throw new DataException("Fine amount must be greater than or equal to 0");
        }
        this.fineAmount = fineAmount;
        this.daysLate = daysLate;
    }

    public double getFineAmount() { return fineAmount; }
    public void setFineAmount(double fineAmount) throws DataException {
        if (fineAmount < 0) {
            throw new DataException("Fine amount must be greater than or equal to 0");
        }
        this.fineAmount = fineAmount;
    }

    public long getDaysLate() { return daysLate; }
    public void setDaysLate(long daysLate) { this.daysLate = daysLate; }
}
