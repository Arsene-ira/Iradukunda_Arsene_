package ID27206.q8;

public class Library extends Entity{
    private String libraryName;
    private String location;
    private String phoneNumber;

    public Library(int id, String libraryName, String location, String phoneNumber) throws DataException {
        super(id);
        if (!isValidPhoneNumber(phoneNumber)) {
            throw new DataException("Invalid phone number format");
        }
        this.libraryName = libraryName;
        this.location = location;
        this.phoneNumber = phoneNumber;
    }

    private boolean isValidPhoneNumber(String phone) {
        return phone != null && phone.matches("\\d{10,15}");
    }

    public String getLibraryName() { return libraryName; }
    public void setLibraryName(String libraryName) { this.libraryName = libraryName; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) throws DataException {
        if (!isValidPhoneNumber(phoneNumber)) {
            throw new DataException("Invalid phone number format");
        }
        this.phoneNumber = phoneNumber;
    }
}
