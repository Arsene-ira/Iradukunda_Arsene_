package ID27206.q8;

import java.time.LocalDate;

public class LibraryRecord extends Record{
    public LibraryRecord(int id, String libraryName, String location, String phoneNumber,
                         String sectionName, String sectionCode,
                         String title, String author, String ISBN,
                         String memberName, int memberId, String contactNumber,
                         LocalDate borrowDate, LocalDate returnDate,
                         double fineAmount, long daysLate,
                         LocalDate paymentDate, String paymentMode,
                         double totalFine) throws DataException {
        super(id, libraryName, location, phoneNumber, sectionName, sectionCode,
                title, author, ISBN, memberName, memberId, contactNumber,
                borrowDate, returnDate, fineAmount, daysLate, paymentDate, paymentMode, totalFine);
    }

    public double calculateFine() {
        return getFineAmount() * getDaysLate();
    }
}
