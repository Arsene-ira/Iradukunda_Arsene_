package ID27206.q9;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TicketRecord extends Invoice{
    public TicketRecord(int id, String airlineName, String address, String contactEmail,
                        String flightNumber, String destination, String departureTime,
                        String passengerName, String passportNumber, String nationality,
                        String seatNumber, String seatType, String ticketNumber, double price,
                        double baggageWeight, double baggageFee,
                        Date paymentDate, String paymentMode) throws DataException {
        super(id, airlineName, address, contactEmail, flightNumber, destination,
                departureTime, passengerName, passportNumber, nationality, seatNumber,
                seatType, ticketNumber, price, baggageWeight, baggageFee, paymentDate, paymentMode);
    }

    public double generateInvoice() {
        return getPrice() + getBaggageFee();
    }

    public void displayTicketRecord() {
        System.out.println("\n" + "=".repeat(70));
        System.out.println("27206 - AIRLINE TICKET BOOKING INVOICE");
        System.out.println("=".repeat(70));
        System.out.println("Ticket Record ID: 27206-" + getId());
        System.out.println("\n--- AIRLINE INFORMATION ---");
        System.out.println("Airline: " + getAirlineName());
        System.out.println("Address: " + getAddress());
        System.out.println("Contact: " + getContactEmail());

        System.out.println("\n--- FLIGHT DETAILS ---");
        System.out.println("Flight Number: " + getFlightNumber());
        System.out.println("Destination: " + getDestination());
        System.out.println("Departure Time: " + getDepartureTime());

        System.out.println("\n--- PASSENGER INFORMATION ---");
        System.out.println("Name: " + getPassengerName());
        System.out.println("Passport: " + getPassportNumber());
        System.out.println("Nationality: " + getNationality());

        System.out.println("\n--- SEAT INFORMATION ---");
        System.out.println("Seat Number: " + getSeatNumber());
        System.out.println("Seat Type: " + getSeatType());

        System.out.println("\n--- TICKET & BAGGAGE ---");
        System.out.println("Ticket Number: " + getTicketNumber());
        System.out.println("Base Ticket Price: $" + String.format("%.2f", getPrice()));
        System.out.println("Baggage Weight: " + getBaggageWeight() + " kg");
        System.out.println("Baggage Fee: $" + String.format("%.2f", getBaggageFee()));

        System.out.println("\n--- PAYMENT INFORMATION ---");
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
        System.out.println("Payment Date: " + sdf.format(getPaymentDate()));
        System.out.println("Payment Mode: " + getPaymentMode());

        System.out.println("\n" + "=".repeat(70));
        System.out.println("TOTAL FARE (27206): $" + String.format("%.2f", getTotalFare()));
        System.out.println("=".repeat(70));
    }
}
