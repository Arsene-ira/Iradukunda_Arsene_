package ID27206.q10;

import java.time.LocalDateTime;

public class Order extends Customer{
    private LocalDateTime orderDate;
    private String orderId;

    public Order(int id, String storeName, String address, String email,
                 String categoryName, String categoryCode,
                 String productName, String productCode, double price,
                 String customerName, String contactNumber, String customerAddress,
                 LocalDateTime orderDate, String orderId) throws DataException {
        super(id, storeName, address, email, categoryName, categoryCode,
                productName, productCode, price, customerName, contactNumber, customerAddress);
        if (orderDate == null) {
            throw new DataException("Order date cannot be empty");
        }
        if (orderId == null || orderId.trim().isEmpty()) {
            throw new DataException("Order ID cannot be empty");
        }
        this.orderDate = orderDate;
        this.orderId = orderId;
    }

    public LocalDateTime getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDateTime orderDate) throws DataException {
        if (orderDate == null) {
            throw new DataException("Order date cannot be empty");
        }
        this.orderDate = orderDate;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) throws DataException {
        if (orderId == null || orderId.trim().isEmpty()) {
            throw new DataException("Order ID cannot be empty");
        }
        this.orderId = orderId;
    }
}
