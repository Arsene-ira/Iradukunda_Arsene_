package ID27206.q10;

public class Store extends Entity{
    private String storeName;
    private String address;
    private String email;

    public Store(int id, String storeName, String address, String email) throws DataException {
        super(id);
        if (!isValidEmail(email)) {
            throw new DataException("Invalid email format");
        }
        this.storeName = storeName;
        this.address = address;
        this.email = email;
    }

    private boolean isValidEmail(String email) {
        return email != null && email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) throws DataException {
        if (!isValidEmail(email)) {
            throw new DataException("Invalid email format");
        }
        this.email = email;
    }
}
