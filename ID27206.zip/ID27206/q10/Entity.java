package ID27206.q10;

import java.time.LocalDateTime;

public class Entity {
    private int id;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;

    public Entity(int id) throws DataException {
        if (id <= 0) {
            throw new DataException("ID must be greater than 0");
        }
        this.id = id;
        this.createdDate = LocalDateTime.now();
        this.updatedDate = LocalDateTime.now();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) throws DataException {
        if (id <= 0) {
            throw new DataException("ID must be greater than 0");
        }
        this.id = id;
        this.updatedDate = LocalDateTime.now();
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }
}
