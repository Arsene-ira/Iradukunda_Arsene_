package ID27206.q10;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

final class OrderRecord extends Invoice{
    public OrderRecord(int id, String storeName, String address, String email,
                       String categoryName, String categoryCode,
                       String productName, String productCode, double price,
                       String customerName, String contactNumber, String customerAddress,
                       LocalDateTime orderDate, String orderId,
                       String paymentMethod, String paymentStatus,
                       String shippingAddress, double shippingCost) throws DataException {
        super(id, storeName, address, email, categoryName, categoryCode,
                productName, productCode, price, customerName, contactNumber, customerAddress,
                orderDate, orderId, paymentMethod, paymentStatus, shippingAddress, shippingCost);
    }

    public double calculateTotalAmount() {
        return getPrice() + getShippingCost();
    }

    public void displayInvoice() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        System.out.println("\n" + "=".repeat(60));
        System.out.println("                    INVOICE - 27206");
        System.out.println("=".repeat(60));
        System.out.println("Order ID: " + getOrderId() + " - 27206");
        System.out.println("Order Date: " + getOrderDate().format(formatter) + " - 27206");
        System.out.println("-".repeat(60));
        System.out.println("STORE INFORMATION - 27206");
        System.out.println("Store: " + getStoreName() + " - 27206");
        System.out.println("Email: " + getEmail() + " - 27206");
        System.out.println("Address: " + getAddress() + " - 27206");
        System.out.println("-".repeat(60));
        System.out.println("CATEGORY INFORMATION - 27206");
        System.out.println("Category: " + getCategoryName() + " - 27206");
        System.out.println("Code: " + getCategoryCode() + " - 27206");
        System.out.println("-".repeat(60));
        System.out.println("CUSTOMER INFORMATION - 27206");
        System.out.println("Name: " + getCustomerName() + " - 27206");
        System.out.println("Contact: " + getContactNumber() + " - 27206");
        System.out.println("Address: " + getCustomerAddress() + " - 27206");
        System.out.println("-".repeat(60));
        System.out.println("PRODUCT INFORMATION - 27206");
        System.out.println("Product: " + getProductName() + " - 27206");
        System.out.println("Product Code: " + getProductCode() + " - 27206");
        System.out.printf("Price: $%.2f - 27206%n", getPrice());
        System.out.println("-".repeat(60));
        System.out.println("SHIPPING INFORMATION - 27206");
        System.out.println("Address: " + getShippingAddress() + " - 27206");
        System.out.printf("Shipping Cost: $%.2f - 27206%n", getShippingCost());
        System.out.println("-".repeat(60));
        System.out.println("PAYMENT INFORMATION - 27206");
        System.out.println("Method: " + getPaymentMethod() + " - 27206");
        System.out.println("Status: " + getPaymentStatus() + " - 27206");
        System.out.println("=".repeat(60));
        System.out.printf("TOTAL AMOUNT: $%.2f - 27206%n", getTotalAmount());
        System.out.printf("CALCULATED TOTAL: $%.2f - 27206%n", calculateTotalAmount());
        System.out.println("=".repeat(60));
    }
}
