package ID27206.q10;

import java.time.LocalDateTime;

public class Invoice extends Shipping{
    private double totalAmount;

    public Invoice(int id, String storeName, String address, String email,
                   String categoryName, String categoryCode,
                   String productName, String productCode, double price,
                   String customerName, String contactNumber, String customerAddress,
                   LocalDateTime orderDate, String orderId,
                   String paymentMethod, String paymentStatus,
                   String shippingAddress, double shippingCost) throws DataException {
        super(id, storeName, address, email, categoryName, categoryCode,
                productName, productCode, price, customerName, contactNumber, customerAddress,
                orderDate, orderId, paymentMethod, paymentStatus, shippingAddress, shippingCost);

        this.totalAmount = price + shippingCost;

        if (totalAmount <= 0) {
            throw new DataException("Total amount must be greater than 0");
        }
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) throws DataException {
        if (totalAmount <= 0) {
            throw new DataException("Total amount must be greater than 0");
        }
        this.totalAmount = totalAmount;
    }
}

