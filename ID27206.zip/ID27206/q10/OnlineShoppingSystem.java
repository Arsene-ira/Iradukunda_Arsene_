package ID27206.q10;

import java.time.LocalDateTime;
import java.util.Scanner;

public class OnlineShoppingSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("=== ONLINE SHOPPING SYSTEM - 27206 ===\n");

            // Entity ID
            System.out.print("Enter Entity ID (must be > 0): ");
            int id = Integer.parseInt(scanner.nextLine());

            // Store Information
            System.out.println("\n--- Store Information - 27206 ---");
            System.out.print("Enter Store Name: ");
            String storeName = scanner.nextLine();
            System.out.print("Enter Store Address: ");
            String storeAddress = scanner.nextLine();
            System.out.print("Enter Store Email: ");
            String storeEmail = scanner.nextLine();
            System.out.println("Store validated successfully - 27206");

            // Category Information
            System.out.println("\n--- Category Information - 27206 ---");
            System.out.print("Enter Category Name (min 3 chars): ");
            String categoryName = scanner.nextLine();
            System.out.print("Enter Category Code (min 3 chars): ");
            String categoryCode = scanner.nextLine();
            System.out.println("Category validated successfully - 27206");

            // Product Information
            System.out.println("\n--- Product Information - 27206 ---");
            System.out.print("Enter Product Name: ");
            String productName = scanner.nextLine();
            System.out.print("Enter Product Code: ");
            String productCode = scanner.nextLine();
            System.out.print("Enter Product Price (must be > 0): ");
            double price = Double.parseDouble(scanner.nextLine());
            System.out.println("Product validated successfully - 27206");

            // Customer Information
            System.out.println("\n--- Customer Information - 27206 ---");
            System.out.print("Enter Customer Name: ");
            String customerName = scanner.nextLine();
            System.out.print("Enter Contact Number: ");
            String contactNumber = scanner.nextLine();
            System.out.print("Enter Customer Address: ");
            String customerAddress = scanner.nextLine();
            System.out.println("Customer validated successfully - 27206");

            // Order Information
            System.out.println("\n--- Order Information - 27206 ---");
            System.out.print("Enter Order ID: ");
            String orderId = scanner.nextLine();
            LocalDateTime orderDate = LocalDateTime.now();
            System.out.println("Order validated successfully - 27206");

            // Payment Information
            System.out.println("\n--- Payment Information - 27206 ---");
            System.out.print("Enter Payment Method (e.g., Credit Card, PayPal): ");
            String paymentMethod = scanner.nextLine();
            System.out.print("Enter Payment Status (e.g., Paid, Pending): ");
            String paymentStatus = scanner.nextLine();
            System.out.println("Payment validated successfully - 27206");

            // Shipping Information
            System.out.println("\n--- Shipping Information - 27206 ---");
            System.out.print("Enter Shipping Address: ");
            String shippingAddress = scanner.nextLine();
            System.out.print("Enter Shipping Cost (must be >= 0): ");
            double shippingCost = Double.parseDouble(scanner.nextLine());
            System.out.println("Shipping validated successfully - 27206");

            // Create OrderRecord (which inherits from all classes)
            System.out.println("\n--- Creating Order Record - 27206 ---");
            OrderRecord orderRecord = new OrderRecord(
                    id, storeName, storeAddress, storeEmail,
                    categoryName, categoryCode,
                    productName, productCode, price,
                    customerName, contactNumber, customerAddress,
                    orderDate, orderId,
                    paymentMethod, paymentStatus,
                    shippingAddress, shippingCost
            );
            System.out.println("Order Record created successfully - 27206");

            // Display Invoice
            orderRecord.displayInvoice();

        } catch (DataException e) {
            System.out.println("\nValidation Error - 27206: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("\nInput Error - 27206: Please enter valid numbers");
        } catch (Exception e) {
            System.out.println("\nError - 27206: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}
