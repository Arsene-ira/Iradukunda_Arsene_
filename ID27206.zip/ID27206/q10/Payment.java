package ID27206.q10;

import java.time.LocalDateTime;

public class Payment extends Order{
    private String paymentMethod;
    private String paymentStatus;

    public Payment(int id, String storeName, String address, String email,
                   String categoryName, String categoryCode,
                   String productName, String productCode, double price,
                   String customerName, String contactNumber, String customerAddress,
                   LocalDateTime orderDate, String orderId,
                   String paymentMethod, String paymentStatus) throws DataException {
        super(id, storeName, address, email, categoryName, categoryCode,
                productName, productCode, price, customerName, contactNumber, customerAddress,
                orderDate, orderId);
        if (paymentMethod == null || paymentMethod.trim().isEmpty()) {
            throw new DataException("Payment method cannot be empty");
        }
        if (paymentStatus == null || paymentStatus.trim().isEmpty()) {
            throw new DataException("Payment status cannot be empty");
        }
        this.paymentMethod = paymentMethod;
        this.paymentStatus = paymentStatus;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) throws DataException {
        if (paymentMethod == null || paymentMethod.trim().isEmpty()) {
            throw new DataException("Payment method cannot be empty");
        }
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) throws DataException {
        if (paymentStatus == null || paymentStatus.trim().isEmpty()) {
            throw new DataException("Payment status cannot be empty");
        }
        this.paymentStatus = paymentStatus;
    }
}
