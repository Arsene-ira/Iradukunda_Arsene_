package ID27206.q3;

import java.util.Scanner;
import java.util.regex.Pattern;

public class EmployeePayrollSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.println("=== EMPLOYEE PAYROLL SYSTEM ===");
            System.out.println("Student ID: 27206\n");

            // Entity Information
            int id = readInt(sc, "Enter Entity ID: ");
            String createdDate = readNonEmptyString(sc, "Enter Created Date (DD-MM-YYYY): ");
            String updatedDate = readNonEmptyString(sc, "Enter Updated Date (DD-MM-YYYY): ");

            // Company Information
            String companyName = readNonEmptyString(sc, "\nEnter Company Name: ");
            String address = readNonEmptyString(sc, "Enter Address: ");
            String companyPhone = readPhone(sc, "Enter Company Phone Number (10 digits): ");
            String companyEmail = readEmail(sc, "Enter Company Email: ");

            // Department Information
            String departmentName = readNonEmptyString(sc, "\nEnter Department Name: ");
            String departmentCode = readDepartmentCode(sc, "Enter Department Code (alphanumeric, min 3 chars): ");

            // Manager Information
            String managerName = readNonEmptyString(sc, "\nEnter Manager Name: ");
            String managerEmail = readEmail(sc, "Enter Manager Email: ");
            String managerPhone = readPhone(sc, "Enter Manager Phone (10 digits): ");

            // Employee Information
            String employeeName = readNonEmptyString(sc, "\nEnter Employee Name: ");
            int employeeId = readInt(sc, "Enter Employee ID: ");
            String designation = readNonEmptyString(sc, "Enter Designation: ");
            String employeeContact = readPhone(sc, "Enter Employee Contact Number (10 digits): ");

            // Attendance Information
            int totalDays = readNonNegativeInt(sc, "\nEnter Total Days in Pay Period: ");
            int presentDays = readNonNegativeInt(sc, "Enter Present Days: ");
            int leaveDays = readNonNegativeInt(sc, "Enter Leave Days: ");
            if (presentDays > totalDays) {
                throw new PayrollDataException("Present days cannot exceed total days");
            }
            if (leaveDays > totalDays) {
                throw new PayrollDataException("Leave days cannot exceed total days");
            }

            // Allowances
            double housingAllowance = readNonNegativeDouble(sc, "\nEnter Housing Allowance: ");
            double transportAllowance = readNonNegativeDouble(sc, "Enter Transport Allowance: ");

            // Deductions
            double taxDeduction = readNonNegativeDouble(sc, "\nEnter Tax Deduction: ");
            double loanDeduction = readNonNegativeDouble(sc, "Enter Loan Deduction: ");

            // Salary
            double basicSalary = readPositiveDouble(sc, "\nEnter Basic Salary: ");

            // Create PayrollRecord and Generate Payslip
            PayrollRecord payroll = new PayrollRecord(id, createdDate, updatedDate,
                    companyName, address, companyPhone, companyEmail,
                    departmentName, departmentCode,
                    managerName, managerEmail, managerPhone,
                    employeeName, employeeId, designation, employeeContact,
                    totalDays, presentDays, leaveDays,
                    housingAllowance, transportAllowance,
                    taxDeduction, loanDeduction,
                    basicSalary);

            payroll.generatePayslip();

        } catch (PayrollDataException e) {
            System.out.println("\n27206 - ERROR: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("\n27206 - ERROR: Invalid input format. " + e.getMessage());
        } finally {
            sc.close();
        }
    }

    // ---------- Input helper methods with validation ----------
    private static String readNonEmptyString(Scanner sc, String prompt) throws PayrollDataException {
        System.out.print(prompt);
        String s = sc.nextLine().trim();
        if (s.isEmpty()) {
            throw new PayrollDataException("Input cannot be empty");
        }
        return s;
    }

    private static int readInt(Scanner sc, String prompt) throws PayrollDataException {
        System.out.print(prompt);
        String line = sc.nextLine().trim();
        try {
            int val = Integer.parseInt(line);
            if (val <= 0) {
                throw new PayrollDataException("Value must be greater than 0");
            }
            return val;
        } catch (NumberFormatException e) {
            throw new PayrollDataException("Expected a valid integer");
        }
    }

    private static int readNonNegativeInt(Scanner sc, String prompt) throws PayrollDataException {
        System.out.print(prompt);
        String line = sc.nextLine().trim();
        try {
            int val = Integer.parseInt(line);
            if (val < 0) {
                throw new PayrollDataException("Value must be non-negative");
            }
            return val;
        } catch (NumberFormatException e) {
            throw new PayrollDataException("Expected a valid integer");
        }
    }

    private static double readNonNegativeDouble(Scanner sc, String prompt) throws PayrollDataException {
        System.out.print(prompt);
        String line = sc.nextLine().trim();
        try {
            double val = Double.parseDouble(line);
            if (val < 0) {
                throw new PayrollDataException("Value must be non-negative");
            }
            return val;
        } catch (NumberFormatException e) {
            throw new PayrollDataException("Expected a valid number");
        }
    }

    private static double readPositiveDouble(Scanner sc, String prompt) throws PayrollDataException {
        System.out.print(prompt);
        String line = sc.nextLine().trim();
        try {
            double val = Double.parseDouble(line);
            if (val <= 0) {
                throw new PayrollDataException("Value must be greater than 0");
            }
            return val;
        } catch (NumberFormatException e) {
            throw new PayrollDataException("Expected a valid number");
        }
    }

    private static String readPhone(Scanner sc, String prompt) throws PayrollDataException {
        System.out.print(prompt);
        String phone = sc.nextLine().trim();
        if (phone.length() != 10 || !phone.matches("\\d+")) {
            throw new PayrollDataException("Phone number must be exactly 10 digits");
        }
        return phone;
    }

    private static String readEmail(Scanner sc, String prompt) throws PayrollDataException {
        System.out.print(prompt);
        String email = sc.nextLine().trim();
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        if (!Pattern.matches(emailRegex, email)) {
            throw new PayrollDataException("Invalid email format");
        }
        return email;
    }

    private static String readDepartmentCode(Scanner sc, String prompt) throws PayrollDataException {
        System.out.print(prompt);
        String code = sc.nextLine().trim();
        if (code.length() < 3 || !code.matches("[A-Za-z0-9]+")) {
            throw new PayrollDataException("Department code must be alphanumeric and at least 3 characters");
        }
        return code;
    }
}