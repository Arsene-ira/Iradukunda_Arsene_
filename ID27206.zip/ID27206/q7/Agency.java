package ID27206.q7;

public class Agency extends Entity{
    private String agencyName;
    private String location;
    private String phoneNumber;

    public Agency(int id, String agencyName, String location, String phoneNumber) throws DataException {
        super(id);
        if (!isValidPhone(phoneNumber)) {
            throw new DataException("Invalid phone number format");
        }
        this.agencyName = agencyName;
        this.location = location;
        this.phoneNumber = phoneNumber;
    }

    private boolean isValidPhone(String phone) {
        return phone != null && phone.matches("\\d{10,15}");
    }

    public String getAgencyName() { return agencyName; }
    public void setAgencyName(String agencyName) { this.agencyName = agencyName; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) throws DataException {
        if (!isValidPhone(phoneNumber)) {
            throw new DataException("Invalid phone number format");
        }
        this.phoneNumber = phoneNumber;
    }
}
