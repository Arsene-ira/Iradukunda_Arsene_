package ID27206.q7;
import java.time.LocalDate;
import java.util.*;

public class Entity {
    private int id;
    private LocalDate createdDate;
    private LocalDate updatedDate;

    public Entity(int id) throws DataException {
        if (id <= 0) {
            throw new DataException("ID must be greater than 0");
        }
        this.id = id;
        this.createdDate = LocalDate.now();
        this.updatedDate = LocalDate.now();
    }

    public int getId() { return id; }
    public void setId(int id) throws DataException {
        if (id <= 0) {
            throw new DataException("ID must be greater than 0");
        }
        this.id = id;
    }

    public LocalDate getCreatedDate() { return createdDate; }
    public LocalDate getUpdatedDate() { return updatedDate; }
    public void setUpdatedDate(LocalDate updatedDate) { this.updatedDate = updatedDate; }
}

