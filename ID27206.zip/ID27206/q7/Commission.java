package ID27206.q7;

import java.time.LocalDate;

public class Commission extends Payment{
    private double commissionRate;
    private double commissionAmount;

    public Commission(int id, String agencyName, String location, String phoneNumber,
                      String agentName, String email, String licenseNumber,
                      String propertyCode, String propertyType, double price,
                      String sellerName, String contactNumber,
                      String buyerName, String buyerEmail,
                      LocalDate agreementDate, String terms,
                      double paymentAmount, LocalDate paymentDate,
                      double commissionRate) throws DataException {
        super(id, agencyName, location, phoneNumber, agentName, email, licenseNumber,
                propertyCode, propertyType, price, sellerName, contactNumber,
                buyerName, buyerEmail, agreementDate, terms, paymentAmount, paymentDate);
        if (commissionRate < 0) {
            throw new DataException("Commission rate must be greater than or equal to 0");
        }
        this.commissionRate = commissionRate;
        this.commissionAmount = 0;
    }

    public double getCommissionRate() { return commissionRate; }
    public void setCommissionRate(double commissionRate) throws DataException {
        if (commissionRate < 0) {
            throw new DataException("Commission rate must be greater than or equal to 0");
        }
        this.commissionRate = commissionRate;
    }
    public double getCommissionAmount() { return commissionAmount; }
    public void setCommissionAmount(double commissionAmount) { this.commissionAmount = commissionAmount; }
}
