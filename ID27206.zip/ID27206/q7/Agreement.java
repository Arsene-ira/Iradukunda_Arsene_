package ID27206.q7;

import java.time.LocalDate;

public class Agreement extends Buyer{
    private LocalDate agreementDate;
    private String terms;

    public Agreement(int id, String agencyName, String location, String phoneNumber,
                     String agentName, String email, String licenseNumber,
                     String propertyCode, String propertyType, double price,
                     String sellerName, String contactNumber,
                     String buyerName, String buyerEmail,
                     LocalDate agreementDate, String terms) throws DataException {
        super(id, agencyName, location, phoneNumber, agentName, email, licenseNumber,
                propertyCode, propertyType, price, sellerName, contactNumber, buyerName, buyerEmail);
        if (terms == null || terms.trim().isEmpty()) {
            throw new DataException("Terms cannot be empty");
        }
        this.agreementDate = agreementDate;
        this.terms = terms;
    }

    public LocalDate getAgreementDate() { return agreementDate; }
    public void setAgreementDate(LocalDate agreementDate) { this.agreementDate = agreementDate; }
    public String getTerms() { return terms; }
    public void setTerms(String terms) throws DataException {
        if (terms == null || terms.trim().isEmpty()) {
            throw new DataException("Terms cannot be empty");
        }
        this.terms = terms;
    }
}
