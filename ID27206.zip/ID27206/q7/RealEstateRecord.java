package ID27206.q7;

import java.time.LocalDate;

public class RealEstateRecord extends Commission{
    public RealEstateRecord(int id, String agencyName, String location, String phoneNumber,
                            String agentName, String email, String licenseNumber,
                            String propertyCode, String propertyType, double price,
                            String sellerName, String contactNumber,
                            String buyerName, String buyerEmail,
                            LocalDate agreementDate, String terms,
                            double paymentAmount, LocalDate paymentDate,
                            double commissionRate) throws DataException {
        super(id, agencyName, location, phoneNumber, agentName, email, licenseNumber,
                propertyCode, propertyType, price, sellerName, contactNumber,
                buyerName, buyerEmail, agreementDate, terms, paymentAmount, paymentDate,
                commissionRate);
        calculateCommission();
    }

    public void calculateCommission() {
        double calculatedAmount = (getPrice() * getCommissionRate()) / 100;
        setCommissionAmount(calculatedAmount);
    }

    public void displayInvoice() {
        System.out.println("\n" + "=".repeat(70));
        System.out.println("27206 - REAL ESTATE TRANSACTION INVOICE");
        System.out.println("=".repeat(70));
        System.out.println("Record ID: 27206-" + getId());
        System.out.println("Created Date: " + getCreatedDate());
        System.out.println("\n--- AGENCY INFORMATION ---");
        System.out.println("Agency Name: " + getAgencyName());
        System.out.println("Location: " + getLocation());
        System.out.println("Phone: " + getPhoneNumber());

        System.out.println("\n--- AGENT INFORMATION ---");
        System.out.println("Agent Name: " + getAgentName());
        System.out.println("Email: " + getEmail());
        System.out.println("License Number: " + getLicenseNumber());

        System.out.println("\n--- PROPERTY INFORMATION ---");
        System.out.println("Property Code: 27206-" + getPropertyCode());
        System.out.println("Property Type: " + getPropertyType());
        System.out.println("Price: $" + String.format("%.2f", getPrice()));

        System.out.println("\n--- SELLER INFORMATION ---");
        System.out.println("Seller Name: " + getSellerName());
        System.out.println("Contact: " + getContactNumber());

        System.out.println("\n--- BUYER INFORMATION ---");
        System.out.println("Buyer Name: " + getBuyerName());
        System.out.println("Email: " + getBuyerEmail());

        System.out.println("\n--- AGREEMENT DETAILS ---");
        System.out.println("Agreement Date: " + getAgreementDate());
        System.out.println("Terms: " + getTerms());

        System.out.println("\n--- PAYMENT DETAILS ---");
        System.out.println("Payment Amount: $" + String.format("%.2f", getPaymentAmount()));
        System.out.println("Payment Date: " + getPaymentDate());

        System.out.println("\n--- COMMISSION CALCULATION ---");
        System.out.println("Commission Rate: " + getCommissionRate() + "%");
        System.out.println("Commission Amount: $27206-" + String.format("%.2f", getCommissionAmount()));

        System.out.println("\n" + "=".repeat(70));
        System.out.println("Total Transaction Value: $27206-" + String.format("%.2f", getPrice()));
        System.out.println("=".repeat(70));
    }
}
