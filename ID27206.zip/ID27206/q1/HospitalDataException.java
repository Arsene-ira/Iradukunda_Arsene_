package ID27206.q1;

public class HospitalDataException extends Exception {
    public HospitalDataException(String message) {
        super(message);
    }
}